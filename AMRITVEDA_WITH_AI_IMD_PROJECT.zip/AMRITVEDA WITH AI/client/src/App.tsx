import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "./hooks/use-auth";

import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Login from "@/pages/auth/Login";
import Register from "@/pages/auth/Register";
import PatientDashboard from "@/pages/dashboard/PatientDashboard";
import PractitionerDashboard from "@/pages/dashboard/PractitionerDashboard";
import DiseasePrediction from "@/pages/tools/DiseasePrediction";
import DoshaQuiz from "@/pages/tools/DoshaQuiz";
import RemedyGenerator from "@/pages/tools/RemedyGenerator";
import Chatbot from "@/pages/tools/Chatbot";
import Profile from "@/pages/Profile";
import Wellness from "@/pages/Wellness";
import MyTreatments from "@/pages/MyTreatments";
import { MainLayout } from "./components/layout/MainLayout";
import { Loader2 } from "lucide-react";

function ProtectedRoute({ component: Component, allowedRole }: { component: any; allowedRole?: "patient" | "practitioner" }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return <Redirect to="/login" />;

  if (allowedRole && user.role !== allowedRole) {
    return <Redirect to={`/dashboard/${user.role}`} />;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/dashboard/patient">
        {() => (
          <MainLayout>
            <ProtectedRoute component={PatientDashboard} allowedRole="patient" />
          </MainLayout>
        )}
      </Route>

      <Route path="/dashboard/practitioner">
        {() => (
          <MainLayout>
            <ProtectedRoute component={PractitionerDashboard} allowedRole="practitioner" />
          </MainLayout>
        )}
      </Route>

      <Route path="/tools/predict">
        {() => <MainLayout><ProtectedRoute component={DiseasePrediction} /></MainLayout>}
      </Route>
      <Route path="/tools/dosha">
        {() => <MainLayout><ProtectedRoute component={DoshaQuiz} /></MainLayout>}
      </Route>
      <Route path="/tools/remedies">
        {() => <MainLayout><ProtectedRoute component={RemedyGenerator} /></MainLayout>}
      </Route>
      <Route path="/tools/chat">
        {() => <MainLayout><ProtectedRoute component={Chatbot} /></MainLayout>}
      </Route>
      <Route path="/wellness">
        {() => <MainLayout><ProtectedRoute component={Wellness} /></MainLayout>}
      </Route>
      <Route path="/profile">
        {() => <MainLayout><ProtectedRoute component={Profile} /></MainLayout>}
      </Route>
      <Route path="/my-treatments">
        {() => <MainLayout><ProtectedRoute component={MyTreatments} allowedRole="patient" /></MainLayout>}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthProvider>
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
