import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Leaf, Activity, Stethoscope, Droplets, MessageCircle, User, LogOut, LayoutDashboard, Users, Youtube, NotebookPen } from "lucide-react";

export function AppSidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const patientMenu = [
    { title: "Dashboard", url: "/dashboard/patient", icon: LayoutDashboard },
    { title: "My Treatments", url: "/my-treatments", icon: NotebookPen },
    { title: "Disease Prediction", url: "/tools/predict", icon: Activity },
    { title: "Dosha Quiz", url: "/tools/dosha", icon: Stethoscope },
    { title: "Natural Remedies", url: "/tools/remedies", icon: Droplets },
    { title: "Ayurveda Chat", url: "/tools/chat", icon: MessageCircle },
    { title: "Wellness Videos", url: "/wellness", icon: Youtube },
  ];

  const practitionerMenu = [
    { title: "Dashboard", url: "/dashboard/practitioner", icon: LayoutDashboard },
    { title: "My Patients", url: "/dashboard/practitioner", icon: Users },
    { title: "Dosha Tools", url: "/tools/dosha", icon: Stethoscope },
    { title: "Natural Remedies", url: "/tools/remedies", icon: Droplets },
    { title: "Disease Prediction", url: "/tools/predict", icon: Activity },
    { title: "Wellness Videos", url: "/wellness", icon: Youtube },
  ];

  const menu = user?.role === "practitioner" ? practitionerMenu : patientMenu;

  return (
    <Sidebar className="border-r border-sidebar-border bg-sidebar/50 backdrop-blur-xl">
      <SidebarHeader className="p-6">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-700/10 p-2.5 rounded-2xl text-emerald-700 dark:text-emerald-400 border border-emerald-700/20 shadow-xs">
            <Leaf className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-bold text-xl text-foreground tracking-tight">AmritVeda</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30">AI</span>
            </div>
            <p className="text-[11px] text-muted-foreground font-medium">Ayurvedic Intelligence</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-wider text-muted-foreground/70">Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menu.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    className="transition-all hover:bg-primary/5 hover:text-primary data-[active=true]:bg-primary/10 data-[active=true]:text-primary"
                  >
                    <Link href={item.url} className="flex items-center gap-3 px-4 py-3 rounded-lg">
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 space-y-1 border-t border-sidebar-border/50">
        {user && (
          <div className="px-4 py-3 mb-2 bg-primary/5 rounded-xl">
            <p className="text-sm font-semibold text-foreground truncate">{user.name}</p>
            <p className="text-xs text-muted-foreground capitalize">{user.role}{user.dosha ? ` • ${user.dosha}` : ""}</p>
          </div>
        )}
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location === "/profile"}>
              <Link href="/profile" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-primary/5">
                <User className="w-5 h-5" />
                <span>Profile</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-destructive hover:bg-destructive/10">
                <LogOut className="w-5 h-5" />
                <span>Logout</span>
              </button>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
