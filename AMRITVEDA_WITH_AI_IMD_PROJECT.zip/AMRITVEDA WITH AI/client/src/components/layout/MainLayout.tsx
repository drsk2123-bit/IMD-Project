import { ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { motion } from "framer-motion";

export function MainLayout({ children }: { children: ReactNode }) {
  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={style}>
      <div className="flex h-screen w-full bg-background/50 overflow-hidden">
        <AppSidebar />
        <div className="flex-1 flex flex-col h-full relative z-10 overflow-hidden">
          <header className="h-16 flex items-center px-4 border-b border-border/40 bg-background/80 backdrop-blur-md z-20">
            <SidebarTrigger className="hover:bg-primary/10 text-primary" />
          </header>
          <main className="flex-1 overflow-y-auto p-4 md:p-8">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="max-w-6xl mx-auto"
            >
              {children}
            </motion.div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
