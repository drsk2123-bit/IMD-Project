import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { fetchWithAuth } from "./use-auth";
import { api } from "@shared/routes";

export function usePredictDisease() {
  return useMutation({
    mutationFn: async (symptoms: string[]) => {
      const payload = api.disease.predict.input.parse({ symptoms });
      return fetchWithAuth(api.disease.predict.path, {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
  });
}

export function useAnalyzeDosha() {
  return useMutation({
    mutationFn: async (answers: Record<string, string>) => {
      const payload = api.dosha.analyze.input.parse({ answers });
      return fetchWithAuth(api.dosha.analyze.path, {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
  });
}

export function useGenerateRemedy() {
  return useMutation({
    mutationFn: async (symptoms: string[]) => {
      const payload = api.remedy.generate.input.parse({ symptoms });
      return fetchWithAuth(api.remedy.generate.path, {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
  });
}

export function useChat() {
  return useMutation({
    mutationFn: async (input: string | { message: string; history?: Array<{ role: "user" | "bot"; content: string }> }) => {
      const payload = typeof input === "string" ? { message: input } : input;
      const parsed = api.chat.send.input.parse(payload);
      return fetchWithAuth(api.chat.send.path, {
        method: "POST",
        body: JSON.stringify(parsed),
      });
    },
  });
}

export function usePatients() {
  return useQuery({
    queryKey: [api.practitioner.patients.path],
    queryFn: async () => {
      return fetchWithAuth(api.practitioner.patients.path);
    },
  });
}

export function usePatientReview(patientId: number | null) {
  return useQuery({
    queryKey: [api.practitioner.patientReview.path, patientId],
    enabled: patientId !== null,
    queryFn: async () => {
      return fetchWithAuth(api.practitioner.patientReview.path.replace(":patientId", String(patientId)));
    },
  });
}

export function useCreateTreatment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ patientId, notes }: { patientId: number; notes: string }) => {
      const payload = api.practitioner.createTreatment.input.parse({ patientId, notes });
      return fetchWithAuth(api.practitioner.createTreatment.path, {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.practitioner.patientReview.path, variables.patientId] });
    },
  });
}

export function usePatientTreatments() {
  return useQuery({
    queryKey: [api.patient.treatments.path],
    queryFn: async () => {
      return fetchWithAuth(api.patient.treatments.path);
    },
  });
}
