import { Link } from "wouter";
import { motion } from "framer-motion";
import { Leaf, Sparkles, ShieldCheck, ArrowRight, Cpu, Activity, HeartHandshake, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col selection:bg-emerald-500/20 selection:text-emerald-900">
      {/* Navbar */}
      <header className="px-6 md:px-12 py-5 flex items-center justify-between z-20 border-b border-border/40 bg-background/80 backdrop-blur-md sticky top-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-700/10 text-emerald-700 dark:text-emerald-400 flex items-center justify-center border border-emerald-700/20 shadow-xs">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-bold text-2xl text-foreground tracking-tight">AmritVeda</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30">AI</span>
            </div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">Ayurvedic Intelligence</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" asChild className="hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-800 text-sm font-medium">
            <Link href="/login">Log In</Link>
          </Button>
          <Button asChild className="bg-emerald-700 hover:bg-emerald-800 text-white rounded-full px-6 shadow-sm shadow-emerald-900/10">
            <Link href="/register">Get Started</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1 flex flex-col">
        {/* Hero Section */}
        <section className="relative flex-1 flex items-center py-20 px-6 md:px-12 overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?q=80&w=2000&auto=format&fit=crop" 
              alt="Ayurvedic Herbs" 
              className="w-full h-full object-cover opacity-10"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/60" />
          </div>
          
          <div className="max-w-7xl mx-auto w-full relative z-10 grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -25 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 border border-emerald-500/20 font-medium text-xs tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Ancient Vedic Wisdom Meets Groq AI & Machine Learning</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-display font-bold text-foreground leading-[1.08] tracking-tight">
                Harmonize Your <br/>
                <span className="text-emerald-700 dark:text-emerald-400 italic">Natural Vitality</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
                AmritVeda bridges authentic Ayurvedic medicine with state-of-the-art AI. Experience precision disease classification with our trained Random Forest model and personalized holistic health guidance powered by Groq AI.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <Button size="lg" asChild className="rounded-full bg-emerald-700 hover:bg-emerald-800 text-white h-14 px-8 text-base shadow-lg shadow-emerald-900/15 hover:-translate-y-0.5 transition-all">
                  <Link href="/register">
                    Begin Health Assessment <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="rounded-full h-14 px-8 text-base border-border hover:bg-muted/60">
                  <Link href="/login">Practitioner Portal</Link>
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>132 Clinical Symptom Features</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Trained ML Classifier</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Groq AI Integration</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden md:block relative"
            >
              <div className="aspect-square rounded-[3rem] overflow-hidden border-8 border-white/70 dark:border-white/10 shadow-2xl relative rotate-2 hover:rotate-0 transition-transform duration-500">
                <img 
                  src="https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1000&auto=format&fit=crop" 
                  alt="Ayurvedic Wellness & Meditation"
                  className="w-full h-full object-cover" 
                />
                <div className="absolute inset-0 bg-emerald-950/20 mix-blend-overlay" />
              </div>
            </motion.div>
          </div>
        </section>

        {/* Feature Cards */}
        <section className="py-24 bg-card/60 border-t border-border/50 relative z-10">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground">
                Engineered for Holistic Wellbeing
              </h2>
              <p className="text-muted-foreground text-base">
                Discover the four pillars powering AmritVeda's clinical and wellness capabilities.
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-6">
              {[
                {
                  title: "Trained ML Disease Model",
                  desc: "Supervised classification across 132 clinical symptoms, predicting conditions with authentic probability scores.",
                  icon: Cpu,
                  tag: "Machine Learning"
                },
                {
                  title: "Groq AI Intelligence",
                  desc: "Deep language understanding and conversational guidance explaining Ayurvedic pathophysiology, herbs, and Ahara.",
                  icon: Sparkles,
                  tag: "Groq AI"
                },
                {
                  title: "Prakriti Dosha Quiz",
                  desc: "Classical algorithmic scoring for Vata, Pitta, and Kapha constitution, personalized with Dinacharya routines.",
                  icon: Activity,
                  tag: "Dosha Analysis"
                },
                {
                  title: "Practitioner Portal",
                  desc: "Comprehensive patient management, longitudinal symptom tracking, and practitioner treatment note creation.",
                  icon: HeartHandshake,
                  tag: "Clinical Care"
                },
              ].map((feature, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-background p-7 rounded-3xl border border-border/70 shadow-sm hover:shadow-md hover:border-emerald-500/40 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-emerald-700/10 flex items-center justify-center text-emerald-700 dark:text-emerald-400 mb-5 border border-emerald-700/15">
                      <feature.icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-1 inline-block">{feature.tag}</span>
                    <h3 className="text-lg font-display font-bold mb-2 text-foreground">{feature.title}</h3>
                    <p className="text-muted-foreground text-xs leading-relaxed">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 px-6 md:px-12 border-t border-border/60 bg-background text-center text-xs text-muted-foreground">
        <p>© {new Date().getFullYear()} AmritVeda. All rights reserved. Built with modern AI and ancient Ayurvedic science.</p>
      </footer>
    </div>
  );
}
