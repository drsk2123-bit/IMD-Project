import { usePatientTreatments } from "@/hooks/use-ayurveda";
import { NotebookPen, UserRound } from "lucide-react";

export default function MyTreatments() {
  const { data: treatments, isLoading } = usePatientTreatments();

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-4xl font-display font-bold text-foreground">My Treatments</h1>
        <p className="text-lg text-muted-foreground mt-2">Review notes shared by your practitioner, including who provided each treatment.</p>
      </header>

      {isLoading ? (
        <div className="bg-card rounded-2xl border border-border p-6 text-muted-foreground">
          Loading treatment notes...
        </div>
      ) : Array.isArray(treatments) && treatments.length > 0 ? (
        <div className="space-y-4">
          {[...treatments].reverse().map((treatment: any) => (
            <div key={treatment.id} className="bg-card rounded-2xl border border-border p-6">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Given By</p>
                  <p className="font-bold text-foreground flex items-center gap-2 mt-1">
                    <UserRound className="w-4 h-4 text-primary" /> {treatment.practitionerName}
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">
                  {new Date(treatment.createdAt).toLocaleDateString("en-IN", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div className="mt-4 rounded-2xl bg-muted/20 border border-border p-4">
                <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{treatment.notes}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-card rounded-2xl border border-border p-10 text-center text-muted-foreground flex flex-col items-center">
          <NotebookPen className="w-12 h-12 mb-4 opacity-20" />
          <p>No treatment notes have been shared yet.</p>
        </div>
      )}
    </div>
  );
}
