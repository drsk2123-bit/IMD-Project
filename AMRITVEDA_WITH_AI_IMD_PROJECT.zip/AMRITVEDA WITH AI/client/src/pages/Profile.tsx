import { useAuth } from "@/hooks/use-auth";
import { User, Calendar, Phone, Activity, Heart } from "lucide-react";

export default function Profile() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <header>
        <h1 className="text-4xl font-display font-bold text-foreground">My Profile</h1>
      </header>

      <div className="bg-card rounded-[2rem] border border-border shadow-sm overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-primary/20 to-accent/20 relative">
          <div className="absolute -bottom-12 left-8 w-24 h-24 bg-background rounded-full p-2">
            <div className="w-full h-full bg-primary/10 rounded-full flex items-center justify-center text-primary text-3xl font-bold uppercase">
              {user.name.charAt(0)}
            </div>
          </div>
        </div>
        
        <div className="pt-16 pb-8 px-8 border-b border-border">
          <h2 className="text-2xl font-bold text-foreground">{user.name}</h2>
          <p className="text-muted-foreground flex items-center gap-2 mt-1">
            <User className="w-4 h-4" /> {user.email}
          </p>
          <div className="mt-4 inline-flex px-3 py-1 bg-secondary text-secondary-foreground text-xs font-semibold rounded-full uppercase tracking-wider">
            {user.role}
          </div>
        </div>

        <div className="p-8 grid sm:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-1">
                <Phone className="w-4 h-4" /> Contact Number
              </label>
              <p className="text-lg text-foreground font-medium">{user.contactNumber || "Not provided"}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4" /> Date of Birth
              </label>
              <p className="text-lg text-foreground font-medium">{user.dob || "Not provided"}</p>
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-1">
                <Heart className="w-4 h-4" /> Blood Group
              </label>
              <p className="text-lg text-foreground font-medium">{user.bloodGroup || "Not provided"}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4" /> Ayurvedic Dosha
              </label>
              <p className="text-lg text-foreground font-medium capitalize">{user.dosha || "Not determined yet"}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
