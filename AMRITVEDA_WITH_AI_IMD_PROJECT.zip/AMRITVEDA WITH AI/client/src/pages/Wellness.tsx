import { useState } from "react";
import { PlayCircle, ExternalLink, Youtube } from "lucide-react";

interface VideoCard {
  id: string;
  title: string;
  channel: string;
  duration: string;
  category: string;
  description: string;
}

const VIDEOS: VideoCard[] = [
  // Yoga
  { id: "v7AYKMP6rOE", title: "Yoga For Complete Beginners", channel: "Yoga With Adriene", duration: "24 min", category: "Yoga", description: "A gentle full-body yoga flow perfect for beginners. Build strength, flexibility and inner calm." },
  { id: "sTANio_2E0Q", title: "Morning Yoga – Energizing Flow", channel: "MadFit", duration: "21 min", category: "Yoga", description: "Start your day with this energizing morning yoga sequence to wake up body and mind." },
  { id: "_ENYL8qxKx0", title: "Surya Namaskar – Sun Salutation", channel: "Yoga With Adriene", duration: "10 min", category: "Yoga", description: "Learn the traditional 12-step Surya Namaskar with proper alignment and breathing." },
  { id: "phuS5VLQy8c", title: "Yoga for Back Pain Relief", channel: "Yoga With Adriene", duration: "31 min", category: "Yoga", description: "Targeted poses to relieve lower back pain, reduce stiffness and improve posture." },
  { id: "VaoV1PrYft4", title: "Yin Yoga – Deep Stretch", channel: "SarahBethYoga", duration: "10 min", category: "Yoga", description: "A slow-paced style of yoga with postures held for longer periods to target deep connective tissue." },
  { id: "hJbRpHZr_d0", title: "Yoga for Stress & Anxiety", channel: "Yoga With Adriene", duration: "28 min", category: "Yoga", description: "Calming yoga sequence designed to reduce stress hormones and promote relaxation." },

  // Pranayama
  { id: "-EH4D_DAvqc", title: "Pranayama – 5 Breathing Exercises", channel: "Swami Ramdev", duration: "17 min", category: "Pranayama", description: "Master five essential pranayama techniques: Anulom Vilom, Bhramari, Kapalbhati, Bhastrika, and Ujjayi." },
  { id: "acUZdGd_3Dg", title: "Kapalbhati Pranayama for Weight Loss", channel: "Art of Living", duration: "3 min", category: "Pranayama", description: "Step-by-step guide to Kapalbhati — the powerful breath of fire that detoxifies and energizes." },
  { id: "VJbfVNe-bfE", title: "Anulom Vilom Breathing Technique", channel: "Yoga With Kamya", duration: "7 min", category: "Pranayama", description: "Alternate nostril breathing to balance Vata, Pitta, and Kapha doshas and calm the nervous system." },
  { id: "4pLUleLdwY4", title: "Yoga Nidra – Deep Relaxation", channel: "Yoga Nidra Network", duration: "14 min", category: "Pranayama", description: "Guided Yoga Nidra for deep restorative rest — one hour of sleep equivalent in 35 minutes." },

  // Ayurvedic Remedies
  { id: "x3E0jDE9itk", title: "Ashwagandha – Benefits & Usage", channel: "Acharya Balkrishna", duration: "13 min", category: "Ayurvedic Remedies", description: "Acharya Balkrishna explains the profound healing properties of Ashwagandha (Indian Ginseng) in Ayurveda." },
  { id: "qDvGBHuTswA", title: "Turmeric Golden Milk – Complete Guide", channel: "Skinny Recepies", duration: "3 min", category: "Ayurvedic Remedies", description: "How to make authentic Haldi Doodh (golden milk) and its benefits for inflammation and immunity." },
  { id: "ga72LnUPeEM", title: "Triphala – The Three Fruits", channel: "The Mystic World", duration: "8 min", category: "Ayurvedic Remedies", description: "Complete guide to Triphala — one of Ayurveda's most powerful herbal formulas for digestion and longevity." },
  { id: "cTRC0gAcXIY", title: "Tulsi (Holy Basil) – Sacred Herb", channel: "Rain Country", duration: "11 min", category: "Ayurvedic Remedies", description: "The miraculous healing properties of Tulsi for immunity, respiratory health, and stress relief." },
  { id: "Zk4iJzNrhIY", title: "Panchakarma Home Detox Guide", channel: "Nityanandam Shree", duration: "14 min", category: "Ayurvedic Remedies", description: "How to do a simple Ayurvedic detox at home using Panchakarma principles and herbal cleansing." },

  // Meditation
  { id: "inpok4MKVLM", title: "5-Minute Guided Meditation", channel: "Goodful", duration: "5 min", category: "Meditation", description: "A beginner-friendly guided mindfulness meditation to reduce anxiety and find inner peace." },
  { id: "MIr3RsUWrdo", title: "Vedic Meditation Technique", channel: "The Mindful Movement", duration: "20 min", category: "Meditation", description: "Sadhguru guides you through ancient Vedic meditation for deeper consciousness and well-being." },
  { id: "NmAHY_tg9Es", title: "Chakra Meditation – 7 Chakras", channel: "Meditative Mind", duration: "22 min", category: "Meditation", description: "A guided meditation journey through all 7 chakras for energy balancing and spiritual awakening." },
  { id: "z6X5oEIg6Ak", title: "Mantra Meditation – Om Chanting", channel: "Goodful", duration: "10 min", category: "Meditation", description: "Experience the healing power of Om chanting and mantra meditation from the Vedic tradition." },

  // Diet & Nutrition
  { id: "gWu0zRWB-eM", title: "Ayurvedic Diet Guide", channel: "The Yoga Institute", duration: "9 min", category: "Ayurvedic Diet", description: "How to eat for your dosha type — complete guide to Ayurvedic nutrition principles and meal planning." },
  { id: "r-2F7YxF-Gs", title: "Sattvic Food – Pure Diet", channel: "The Yoga Institute", duration: "6 min", category: "Ayurvedic Diet", description: "Understanding sattvic diet principles — the Ayurvedic approach to eating for mental clarity and spiritual growth." },
  { id: "9lUXr9A52Iw", title: "Ayurvedic Cooking Basics", channel: "Vishuddhi Issha Yoga & Ayurveda ", duration: "15 min", category: "Ayurvedic Diet", description: "Learn to cook with healing spices — turmeric, cumin, coriander, fennel, and ginger for optimal digestion." },

  // Specific Conditions
  { id: "TSnxM9DbppY", title: "Yoga for Diabetes Management", channel: "Bharatha Yoga", duration: "28 min", category: "Therapeutic Yoga", description: "Specific yoga asanas proven to help manage blood sugar levels and improve insulin sensitivity." },
  { id: "rmNzv9D4QMs", title: "Yoga for Thyroid Health", channel: "Akshaya Agnes", duration: "18 min", category: "Therapeutic Yoga", description: "Targeted yoga poses to stimulate and balance thyroid function naturally." },
  { id: "5JvbjrLESPs", title: "Yoga for Hormonal Balance (PCOS)", channel: "Akshaya Agnes", duration: "23 min", category: "Therapeutic Yoga", description: "Yoga sequence specially designed for hormonal imbalance, PCOS, and menstrual health." },
];

const CATEGORIES = ["All", "Yoga", "Pranayama", "Ayurvedic Remedies", "Meditation", "Ayurvedic Diet", "Therapeutic Yoga"];

const CATEGORY_COLORS: Record<string, string> = {
  Yoga: "bg-green-100 text-green-700",
  Pranayama: "bg-blue-100 text-blue-700",
  "Ayurvedic Remedies": "bg-amber-100 text-amber-700",
  Meditation: "bg-purple-100 text-purple-700",
  "Ayurvedic Diet": "bg-orange-100 text-orange-700",
  "Therapeutic Yoga": "bg-teal-100 text-teal-700",
};

export default function Wellness() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [playingId, setPlayingId] = useState<string | null>(null);

  const filtered = activeCategory === "All" ? VIDEOS : VIDEOS.filter((v) => v.category === activeCategory);

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      <header className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2 flex items-center gap-3">
            <Youtube className="w-9 h-9 text-red-500" /> Wellness Hub
          </h1>
          <p className="text-muted-foreground text-lg">
            Curated Ayurvedic videos — yoga, pranayama, remedies, meditation & more
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-red-50 dark:bg-red-950/20 rounded-full border border-red-200 dark:border-red-900/40 text-red-600 text-sm font-medium">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          {VIDEOS.length} videos available
        </div>
      </header>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full text-sm font-medium border transition-all ${
              activeCategory === cat
                ? "bg-primary text-white border-primary shadow-md shadow-primary/20"
                : "bg-card border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
            }`}
          >
            {cat}
            {cat !== "All" && (
              <span className="ml-2 text-xs opacity-70">({VIDEOS.filter((v) => v.category === cat).length})</span>
            )}
          </button>
        ))}
      </div>

      {/* Video Grid */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filtered.map((video) => (
          <div key={video.id} className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all group">
            {/* Thumbnail / Player */}
            <div className="relative aspect-video bg-black overflow-hidden">
              {playingId === video.id ? (
                <iframe
                  src={`https://www.youtube.com/embed/${video.id}?autoplay=1`}
                  title={video.title}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <>
                  <img
                    src={`https://img.youtube.com/vi/${video.id}/maxresdefault.jpg`}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`;
                    }}
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <button
                      onClick={() => setPlayingId(video.id)}
                      className="w-16 h-16 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center text-white shadow-xl transition-all hover:scale-110"
                    >
                      <PlayCircle className="w-8 h-8" />
                    </button>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-0.5 rounded font-medium">
                    {video.duration}
                  </div>
                </>
              )}
            </div>

            {/* Info */}
            <div className="p-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[video.category] || "bg-gray-100 text-gray-700"}`}>
                  {video.category}
                </span>
                <a
                  href={`https://www.youtube.com/watch?v=${video.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
              <h3 className="font-bold text-foreground leading-snug">{video.title}</h3>
              <p className="text-xs text-primary font-medium">{video.channel}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{video.description}</p>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <Youtube className="w-12 h-12 mx-auto mb-4 opacity-20" />
          <p>No videos in this category.</p>
        </div>
      )}
    </div>
  );
}
