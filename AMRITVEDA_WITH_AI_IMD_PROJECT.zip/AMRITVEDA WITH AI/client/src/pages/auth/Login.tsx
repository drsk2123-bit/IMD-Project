import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Leaf, Loader2, Sparkles, UserCheck, Stethoscope } from "lucide-react";
import { api } from "@shared/routes";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const onSubmit = async (data: LoginForm) => {
    setIsLoading(true);
    try {
      const res = await fetch(api.auth.login.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to login");

      login(json.token, json.user);
      toast({ title: "Welcome back!", description: `Logged in as ${json.user.name}.` });

      const destination =
        json.user.role === "practitioner"
          ? "/dashboard/practitioner"
          : "/dashboard/patient";
      setLocation(destination);
    } catch (error: any) {
      toast({ title: "Login failed", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const fillCredentials = (email: string, pass: string) => {
    form.setValue("email", email);
    form.setValue("password", pass);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-amber-500/10 rounded-full blur-[100px]" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-card border border-border rounded-3xl p-8 md:p-10 relative z-10 shadow-xl"
      >
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-emerald-700/10 text-emerald-700 dark:text-emerald-400 rounded-2xl flex items-center justify-center border border-emerald-700/20 shadow-xs">
            <Leaf className="w-8 h-8" />
          </div>
        </div>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3 h-3 text-amber-600" />
            <span>AmritVeda AI Platform</span>
          </div>
          <h1 className="text-3xl font-display font-bold text-foreground">Welcome Back</h1>
          <p className="text-muted-foreground text-sm mt-1">Sign in to your personalized Ayurvedic portal</p>
        </div>

        {/* Demo Credentials Quick-Fill */}
        <div className="mb-6 p-3 rounded-2xl bg-muted/40 border border-border/70 space-y-2">
          <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Quick Fill Demo Accounts:</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fillCredentials("patient@example.com", "password123")}
              className="px-2.5 py-1.5 rounded-xl bg-background hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-border text-xs text-foreground font-medium flex items-center justify-center gap-1.5 transition-all"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Demo Patient</span>
            </button>
            <button
              type="button"
              onClick={() => fillCredentials("practitioner@amritveda.com", "password123")}
              className="px-2.5 py-1.5 rounded-xl bg-background hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-border text-xs text-foreground font-medium flex items-center justify-center gap-1.5 transition-all"
            >
              <Stethoscope className="w-3.5 h-3.5 text-amber-600" />
              <span>Practitioner</span>
            </button>
          </div>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Email Address
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              className="h-12 rounded-xl bg-background"
              data-testid="input-email"
              {...form.register("email")}
            />
            {form.formState.errors.email && (
              <p className="text-xs text-destructive">{form.formState.errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Password
              </Label>
            </div>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              className="h-12 rounded-xl bg-background"
              data-testid="input-password"
              {...form.register("password")}
            />
            {form.formState.errors.password && (
              <p className="text-xs text-destructive">{form.formState.errors.password.message}</p>
            )}
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            data-testid="button-login"
            className="w-full h-12 rounded-xl text-base bg-emerald-700 hover:bg-emerald-800 text-white shadow-md shadow-emerald-900/10 font-semibold"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Sign In to AmritVeda"}
          </Button>
        </form>

        <p className="text-center mt-6 text-xs text-muted-foreground">
          Don't have an account?{" "}
          <Link href="/register" className="text-emerald-700 dark:text-emerald-400 font-semibold hover:underline">
            Register here
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
