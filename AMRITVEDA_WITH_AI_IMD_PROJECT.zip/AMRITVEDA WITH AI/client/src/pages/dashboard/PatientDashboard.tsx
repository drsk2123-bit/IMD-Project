import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Activity, Droplets, Stethoscope, MessageCircle, ArrowRight, Wind, Flame, Youtube, Leaf, Sparkles, NotebookPen, UserRound } from "lucide-react";
import { usePatientTreatments } from "@/hooks/use-ayurveda";

const DOSHA_INFO = {
  Vata: { color: "blue", icon: Wind, desc: "Air & Ether — governs movement, creativity and nervous system", tips: ["Stay warm and grounded", "Eat warm cooked foods", "Maintain a regular routine", "Avoid cold and raw foods"] },
  Pitta: { color: "orange", icon: Flame, desc: "Fire & Water — governs digestion, metabolism and transformation", tips: ["Stay cool and relaxed", "Avoid spicy & fermented foods", "Practice cooling pranayama", "Spend time in nature"] },
  Kapha: { color: "green", icon: Droplets, desc: "Water & Earth — governs structure, immunity and stability", tips: ["Stay active and energized", "Avoid heavy and oily foods", "Exercise vigorously daily", "Wake up before sunrise"] },
};

const TOOLS = [
  { title: "Dosha Quiz", desc: "Identify your Ayurvedic body constitution (Prakriti) with clinical scoring", icon: Stethoscope, color: "text-blue-600", bg: "bg-blue-500/10", link: "/tools/dosha", tag: "Prakriti Analysis" },
  { title: "Disease Prediction", desc: "Supervised ML classifier across 132 symptoms with Groq AI explanation", icon: Activity, color: "text-emerald-600", bg: "bg-emerald-500/10", link: "/tools/predict", tag: "Trained ML Model" },
  { title: "Natural Remedies", desc: "Ayurvedic herbal preparations, healing Ahara & therapeutic recipes", icon: Droplets, color: "text-green-600", bg: "bg-green-600/10", link: "/tools/remedies", tag: "Dravyaguna AI" },
  { title: "Veda AI Assistant", desc: "Consult Veda, your 24/7 intelligent Ayurvedic conversational assistant", icon: MessageCircle, color: "text-purple-500", bg: "bg-purple-500/10", link: "/tools/chat", tag: "Groq AI" },
  { title: "Wellness Practices", desc: "Curated yoga asanas, pranayama, meditation & Dinacharya routines", icon: Youtube, color: "text-red-500", bg: "bg-red-500/10", link: "/wellness", tag: "Yoga & Therapy" },
];

const QUICK_FACTS = [
  { emoji: "🌿", title: "Ashwagandha", desc: "Adaptogen herb for stress relief & energy boost. Take 500mg with warm milk." },
  { emoji: "🟡", title: "Turmeric (Haldi)", desc: "Anti-inflammatory powerhouse. Add to warm milk with black pepper for absorption." },
  { emoji: "🫐", title: "Amalaki (Amla)", desc: "Highest natural Vitamin C source. Boosts immunity and reverses aging." },
  { emoji: "🌱", title: "Tulsi (Holy Basil)", desc: "Sacred herb for respiratory health, immunity & stress adaptation." },
  { emoji: "🔵", title: "Brahmi", desc: "Neuroprotective herb for memory, focus & cognitive enhancement." },
  { emoji: "🟤", title: "Triphala", desc: "Three-fruit blend for gut health, detox & regular elimination. Take at bedtime." },
];

export default function PatientDashboard() {
  const { user } = useAuth();
  const { data: treatments } = usePatientTreatments();

  const doshaKey = user?.dosha as keyof typeof DOSHA_INFO;
  const doshaData = doshaKey ? DOSHA_INFO[doshaKey] : null;

  return (
    <div className="space-y-8 pb-8">
      {/* Greeting */}
      <header>
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-4xl font-bold text-foreground">
              Namaste, {user?.name?.split(" ")[0] || "Friend"} 🙏
            </h1>
            <p className="text-lg text-muted-foreground mt-1">Welcome to your personalized Ayurvedic wellness journey.</p>
          </div>
          <div className="text-right text-sm text-muted-foreground">
            <p className="font-medium text-foreground">{new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
            <p className="text-xs mt-0.5">Your wellness companion</p>
          </div>
        </div>
      </header>

      {/* Dosha Banner */}
      {doshaData ? (
        <div className={`bg-gradient-to-r from-${doshaData.color}-500/10 to-${doshaData.color}-600/5 rounded-3xl p-7 border border-${doshaData.color}-200 dark:border-${doshaData.color}-900/40`}>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className={`w-14 h-14 bg-${doshaData.color}-500/10 text-${doshaData.color}-600 rounded-2xl flex items-center justify-center shrink-0`}>
                <doshaData.icon className="w-7 h-7" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Your Primary Dosha</p>
                <h2 className={`text-3xl font-bold text-${doshaData.color}-600 mb-1`}>{user?.dosha}</h2>
                <p className="text-muted-foreground text-sm">{doshaData.desc}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 md:min-w-[280px]">
              {doshaData.tips.map((tip, i) => (
                <div key={i} className="text-xs bg-white/60 dark:bg-white/5 rounded-lg p-2 text-foreground leading-tight">
                  ✓ {tip}
                </div>
              ))}
            </div>
          </div>
          <div className="mt-5 flex gap-3">
            <Link href="/tools/remedies" className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-white font-medium rounded-full text-sm shadow-md shadow-primary/20 hover:bg-primary/90 transition-colors">
              View My Remedies <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/tools/dosha" className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/70 dark:bg-white/10 text-foreground font-medium rounded-full text-sm hover:bg-white transition-colors">
              Retake Quiz
            </Link>
          </div>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-3xl p-7 border border-primary/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary bg-primary/10 px-3 py-1 rounded-full mb-3">
                <Sparkles className="w-3 h-3" /> Recommended First Step
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Discover Your Dosha</h2>
              <p className="text-muted-foreground max-w-lg">
                Your Prakriti (body constitution) determines your ideal diet, lifestyle, and wellness routine. Take our 12-question quiz to unlock personalized Ayurvedic guidance.
              </p>
            </div>
            <Link href="/tools/dosha" className="shrink-0 inline-flex items-center gap-2 px-7 py-3.5 bg-primary text-white font-semibold rounded-full shadow-lg shadow-primary/25 hover:bg-primary/90 hover:-translate-y-0.5 transition-all text-base">
              Take the Quiz <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      )}

      {/* Tools Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-5 flex items-center gap-2">
          <Leaf className="w-6 h-6 text-primary" /> Wellness Tools
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {TOOLS.map((tool) => (
            <Link key={tool.title} href={tool.link}>
              <div className="bg-card rounded-2xl p-5 border border-border hover:border-primary/30 hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer h-full flex flex-col relative overflow-hidden group">
                {tool.tag && (
                  <span className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-wide bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    {tool.tag}
                  </span>
                )}
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-3 ${tool.bg} ${tool.color} group-hover:scale-110 transition-transform`}>
                  <tool.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold mb-1.5 text-foreground">{tool.title}</h3>
                <p className="text-muted-foreground text-xs flex-1 leading-relaxed">{tool.desc}</p>
                <div className={`mt-3 text-xs font-medium ${tool.color} flex items-center gap-1`}>
                  Explore <ArrowRight className="w-3 h-3" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-5 flex items-center gap-2">
          <NotebookPen className="w-6 h-6 text-primary" /> Treatment Notes
        </h2>
        {Array.isArray(treatments) && treatments.length > 0 ? (
          <div className="grid gap-4">
            {[...treatments].reverse().map((treatment: any) => (
              <div key={treatment.id} className="bg-card rounded-2xl p-5 border border-border">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Given By</p>
                    <p className="font-bold text-foreground flex items-center gap-2 mt-1">
                      <UserRound className="w-4 h-4 text-primary" /> {treatment.practitionerName}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {new Date(treatment.createdAt).toLocaleDateString("en-IN", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>
                <p className="text-sm text-foreground leading-relaxed mt-4 whitespace-pre-wrap">{treatment.notes}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-2xl p-6 border border-border text-muted-foreground text-sm">
            No treatment notes have been shared by your practitioner yet.
          </div>
        )}
      </div>

      {/* Herb of the Day */}
      <div>
        <h2 className="text-2xl font-bold mb-5 flex items-center gap-2">
          🌿 Ayurvedic Herb Encyclopedia
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {QUICK_FACTS.map((fact) => (
            <div key={fact.title} className="bg-card rounded-2xl p-5 border border-border flex items-start gap-4 hover:border-primary/30 transition-colors">
              <span className="text-3xl shrink-0">{fact.emoji}</span>
              <div>
                <h4 className="font-bold text-foreground mb-1">{fact.title}</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">{fact.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-amber-50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/40 p-5 flex items-start gap-3">
        <span className="text-xl shrink-0">⚕️</span>
        <p className="text-sm text-amber-800 dark:text-amber-300 leading-relaxed">
          <strong>Medical Disclaimer:</strong> The information provided on this platform is for educational purposes only and does not constitute medical advice. Always consult a qualified Ayurvedic practitioner or healthcare professional before starting any treatment.
        </p>
      </div>
    </div>
  );
}
