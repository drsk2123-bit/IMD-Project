import { useEffect, useMemo, useState } from "react";
import { useCreateTreatment, usePatientReview, usePatients } from "@/hooks/use-ayurveda";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Activity, CalendarDays, FileText, HeartPulse, Mail, NotebookPen, Phone, User, UserRoundSearch } from "lucide-react";

type Patient = {
  id: number;
  name: string;
  email: string;
  contactNumber?: string | null;
  dob?: string | null;
  bloodGroup?: string | null;
  dosha?: string | null;
  role: string;
};

type Prediction = {
  id: number;
  predictedDisease: string;
  confidence: string;
  symptoms: string[];
  remedies: string[];
  foods: string[];
  createdAt: string;
};

type Treatment = {
  id: number;
  notes: string;
  createdAt: string;
};

function formatDate(value?: string | null) {
  if (!value) return "Not provided";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString();
}

export default function PractitionerDashboard() {
  const { data: patients, isLoading } = usePatients();
  const patientList = (patients as Patient[] | undefined) || [];
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const reviewQuery = usePatientReview(selectedPatientId);
  const createTreatment = useCreateTreatment();

  useEffect(() => {
    if (!selectedPatientId && patientList.length > 0) {
      setSelectedPatientId(patientList[0].id);
    }
  }, [patientList, selectedPatientId]);

  const selectedPatient = useMemo(
    () => patientList.find((patient) => patient.id === selectedPatientId) || null,
    [patientList, selectedPatientId],
  );

  const handleSaveNote = () => {
    if (!selectedPatientId || !notes.trim()) return;
    createTreatment.mutate(
      { patientId: selectedPatientId, notes: notes.trim() },
      {
        onSuccess: () => setNotes(""),
      },
    );
  };

  const review = reviewQuery.data as { patient: Patient; predictions: Prediction[]; treatments: Treatment[] } | undefined;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-4xl font-display font-bold text-foreground">Practitioner Dashboard</h1>
        <p className="text-lg text-muted-foreground mt-2">Review patient details, track prediction history, and save treatment notes.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center">
            <User className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Patients</p>
            <p className="text-2xl font-bold">{isLoading ? "-" : patientList.length}</p>
          </div>
        </div>

        <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-600 flex items-center justify-center">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Saved Predictions</p>
            <p className="text-2xl font-bold">{review?.predictions?.length ?? 0}</p>
          </div>
        </div>

        <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-600 flex items-center justify-center">
            <NotebookPen className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Treatment Notes</p>
            <p className="text-2xl font-bold">{review?.treatments?.length ?? 0}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[360px_minmax(0,1fr)] gap-6">
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          <div className="p-6 border-b border-border bg-muted/20">
            <h2 className="text-xl font-bold">Patient Review</h2>
            <p className="text-sm text-muted-foreground mt-1">Choose a patient to inspect profile, history, and notes.</p>
          </div>

          <div className="p-4">
            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-16 w-full rounded-xl" />
                <Skeleton className="h-16 w-full rounded-xl" />
                <Skeleton className="h-16 w-full rounded-xl" />
              </div>
            ) : patientList.length > 0 ? (
              <div className="space-y-3">
                {patientList.map((patient) => {
                  const isSelected = patient.id === selectedPatientId;
                  return (
                    <button
                      key={patient.id}
                      onClick={() => setSelectedPatientId(patient.id)}
                      className={`w-full text-left rounded-2xl border p-4 transition-all ${
                        isSelected
                          ? "border-primary bg-primary/5 shadow-sm"
                          : "border-border hover:border-primary/30 hover:bg-muted/20"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <h3 className="font-bold text-foreground truncate">{patient.name}</h3>
                          <p className="text-sm text-muted-foreground truncate">{patient.email}</p>
                        </div>
                        <div className="w-10 h-10 rounded-full bg-accent/20 text-accent-foreground flex items-center justify-center font-bold uppercase shrink-0">
                          {patient.name.charAt(0)}
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <span className="px-2.5 py-1 rounded-full bg-muted text-xs text-muted-foreground">
                          {patient.contactNumber || "No number"}
                        </span>
                        {patient.dosha && (
                          <span className="px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                            {patient.dosha}
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground flex flex-col items-center">
                <UserRoundSearch className="w-12 h-12 mb-4 opacity-20" />
                <p>No patients assigned yet.</p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          {selectedPatient ? (
            <>
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="p-6 border-b border-border bg-muted/20 flex items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold">{selectedPatient.name}</h2>
                    <p className="text-sm text-muted-foreground mt-1">Patient profile and clinical overview.</p>
                  </div>
                  {selectedPatient.dosha && (
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                      {selectedPatient.dosha}
                    </span>
                  )}
                </div>

                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-xl border border-border p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <Mail className="w-4 h-4" />
                      <span className="text-sm font-medium">Email</span>
                    </div>
                    <p className="font-semibold text-foreground break-all">{selectedPatient.email}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <Phone className="w-4 h-4" />
                      <span className="text-sm font-medium">Contact</span>
                    </div>
                    <p className="font-semibold text-foreground">{selectedPatient.contactNumber || "Not provided"}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <CalendarDays className="w-4 h-4" />
                      <span className="text-sm font-medium">Date of Birth</span>
                    </div>
                    <p className="font-semibold text-foreground">{selectedPatient.dob || "Not provided"}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <HeartPulse className="w-4 h-4" />
                      <span className="text-sm font-medium">Blood Group</span>
                    </div>
                    <p className="font-semibold text-foreground">{selectedPatient.bloodGroup || "Not provided"}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border border-border overflow-hidden">
                  <div className="p-6 border-b border-border bg-muted/20">
                    <h3 className="text-xl font-bold">Prediction History</h3>
                    <p className="text-sm text-muted-foreground mt-1">Recent disease-analysis records for this patient.</p>
                  </div>
                  <div className="p-6">
                    {reviewQuery.isLoading ? (
                      <div className="space-y-4">
                        <Skeleton className="h-28 w-full rounded-xl" />
                        <Skeleton className="h-28 w-full rounded-xl" />
                      </div>
                    ) : review?.predictions?.length ? (
                      <div className="space-y-4">
                        {review.predictions
                          .slice()
                          .reverse()
                          .map((prediction) => (
                            <div key={prediction.id} className="rounded-2xl border border-border p-4 bg-muted/10">
                              <div className="flex items-start justify-between gap-3">
                                <div>
                                  <h4 className="font-bold text-foreground">{prediction.predictedDisease}</h4>
                                  <p className="text-xs text-muted-foreground mt-1">{formatDate(prediction.createdAt)}</p>
                                </div>
                                <span className="px-2.5 py-1 rounded-full bg-green-100 text-green-700 text-xs font-medium">
                                  {prediction.confidence}
                                </span>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-2">
                                {(prediction.symptoms || []).map((symptom, index) => (
                                  <span key={`${prediction.id}-${index}`} className="px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs">
                                    {symptom}
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No saved predictions yet for this patient.</p>
                    )}
                  </div>
                </div>

                <div className="bg-card rounded-2xl border border-border overflow-hidden">
                  <div className="p-6 border-b border-border bg-muted/20">
                    <h3 className="text-xl font-bold">Treatment Notes</h3>
                    <p className="text-sm text-muted-foreground mt-1">Write your review notes and keep a visit history.</p>
                  </div>
                  <div className="p-6 space-y-4">
                    <Textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Add observations, advice, medicines, lifestyle instructions, or follow-up plans..."
                      className="min-h-[140px] rounded-xl"
                    />
                    <Button
                      onClick={handleSaveNote}
                      disabled={!notes.trim() || createTreatment.isPending || !selectedPatientId}
                      className="rounded-xl"
                    >
                      {createTreatment.isPending ? "Saving..." : "Save Treatment Note"}
                    </Button>

                    <div className="space-y-3 pt-2">
                      {reviewQuery.isLoading ? (
                        <>
                          <Skeleton className="h-24 w-full rounded-xl" />
                          <Skeleton className="h-24 w-full rounded-xl" />
                        </>
                      ) : review?.treatments?.length ? (
                        review.treatments
                          .slice()
                          .reverse()
                          .map((treatment) => (
                            <div key={treatment.id} className="rounded-2xl border border-border p-4 bg-muted/10">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                                <FileText className="w-4 h-4" />
                                <span>{formatDate(treatment.createdAt)}</span>
                              </div>
                              <p className="text-sm leading-relaxed text-foreground whitespace-pre-wrap">{treatment.notes}</p>
                            </div>
                          ))
                      ) : (
                        <p className="text-sm text-muted-foreground">No treatment notes saved yet for this patient.</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-card rounded-2xl border border-border p-12 text-center text-muted-foreground">
              Select a patient to review their details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
