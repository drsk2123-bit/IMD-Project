import { useState, useRef, useEffect } from "react";
import { useChat } from "@/hooks/use-ayurveda";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, User, Sparkles, Loader2, Bot, ShieldAlert, Cpu } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Message {
  role: "user" | "bot";
  content: string;
}

const SUGGESTED_QUESTIONS = [
  "What is my Dosha and how can I balance it?",
  "Best herbs for improving digestion naturally (Agni)",
  "Ayurvedic morning routine (Dinacharya) guidelines",
  "Natural remedies for stress, anxiety, and insomnia",
  "Foods to boost immunity (Ojas) in Ayurveda",
  "How does Ashwagandha help the body and mind?",
  "Best yoga poses for lower back and joint stiffness",
  "What is Triphala and how should I take it?",
  "Ayurvedic recommendations for seasonal detox (Ritucharya)",
  "How to identify Vata, Pitta, and Kapha imbalances?",
];

export default function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      content:
        "Namaste! 🙏 I am Veda, your Ayurvedic wellness guide at AmritVeda, powered by Groq AI.\n\nI combine ancient Ayurvedic wisdom (Charaka & Sushruta Samhita) with clinical wellness principles. How can I assist your health and wellness journey today? You can ask about herbs, doshas, dietary healing, or daily routines.",
    },
  ]);
  const [input, setInput] = useState("");
  const chatMutation = useChat();
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, chatMutation.isPending]);

  const handleSend = async (msg?: string) => {
    const userMsg = (msg || input).trim();
    if (!userMsg || chatMutation.isPending) return;

    setInput("");
    const currentMessages = messages;
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);

    const historyPayload = currentMessages.slice(-6).map((m) => ({
      role: m.role,
      content: m.content,
    }));

    chatMutation.mutate(
      { message: userMsg, history: historyPayload },
      {
        onSuccess: (data) => {
          setMessages((prev) => [...prev, { role: "bot", content: data.response }]);
        },
        onError: (err) => {
          setMessages((prev) => [
            ...prev,
            {
              role: "bot",
              content:
                err instanceof Error
                  ? err.message
                  : "Namaste! I am currently unable to connect to the Groq AI engine. Please verify the server configuration and try again shortly.",
            },
          ]);
        },
      }
    );
  };

  const hasMessages = messages.length > 1;

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col gap-4 px-4 pb-4">
      {/* Header */}
      <header className="flex items-center justify-between shrink-0 pt-2">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 bg-emerald-700/10 text-emerald-700 dark:text-emerald-400 rounded-2xl flex items-center justify-center shrink-0 border border-emerald-700/20 shadow-sm">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-display font-bold text-foreground">
              Veda — AmritVeda AI Assistant
            </h1>
            <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
              <span>Ancient Vedic Wisdom • Powered by Groq AI</span>
            </p>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-muted/60 border border-border text-xs text-muted-foreground font-medium">
            <Cpu className="w-3.5 h-3.5 text-emerald-600" />
            <span>Groq AI Engine</span>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="flex-1 bg-card border border-border rounded-3xl shadow-sm overflow-hidden flex flex-col min-h-0">
        <div ref={scrollRef} className="flex-1 p-5 md:p-6 overflow-y-auto space-y-5">
          <AnimatePresence initial={false}>
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div
                  className={`w-9 h-9 shrink-0 rounded-2xl flex items-center justify-center shadow-xs ${
                    msg.role === "user"
                      ? "bg-emerald-700 text-white"
                      : "bg-emerald-700/10 text-emerald-800 dark:text-emerald-300 border border-emerald-700/20"
                  }`}
                >
                  {msg.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div
                  className={`max-w-[85%] md:max-w-[78%] p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-emerald-700 text-white rounded-tr-xs shadow-sm"
                      : "bg-muted/40 text-foreground border border-border/60 rounded-tl-xs"
                  }`}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {chatMutation.isPending && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
                <div className="w-9 h-9 shrink-0 rounded-2xl bg-emerald-700/10 text-emerald-800 dark:text-emerald-300 flex items-center justify-center border border-emerald-700/20">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="p-4 rounded-2xl bg-muted/40 text-muted-foreground flex items-center gap-2.5 text-sm rounded-tl-xs border border-border/60">
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-700" />
                  <span>Veda is consulting Ayurvedic principles with Groq AI...</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Suggested Questions */}
          {!hasMessages && !chatMutation.isPending && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 pt-4 border-t border-border/50">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-3 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" /> Suggested Explorations
              </p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTED_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSend(q)}
                    className="px-3.5 py-2 text-xs bg-background hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:text-emerald-800 dark:hover:text-emerald-300 border border-border hover:border-emerald-500/40 rounded-xl transition-all text-muted-foreground font-medium shadow-2xs"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-border bg-card/60 backdrop-blur-md">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about herbs, doshas, dietary regimens, home remedies..."
              className="flex-1 h-12 pr-4 rounded-xl bg-background border-border shadow-2xs text-sm focus-visible:ring-emerald-600"
              data-testid="input-chat"
            />
            <Button
              type="submit"
              size="icon"
              disabled={!input.trim() || chatMutation.isPending}
              className="h-12 w-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white shrink-0 shadow-md shadow-emerald-900/10"
              data-testid="button-send-chat"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
          <p className="text-[11px] text-muted-foreground text-center mt-2 flex items-center justify-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
            <span>
              AmritVeda AI provides holistic wellness guidance. It does not replace medical advice or emergency care.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
