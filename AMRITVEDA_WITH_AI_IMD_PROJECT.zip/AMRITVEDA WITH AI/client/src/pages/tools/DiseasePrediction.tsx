import { useState, useMemo } from "react";
import { usePredictDisease } from "@/hooks/use-ayurveda";
import { Button } from "@/components/ui/button";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Sparkles,
  X,
  Leaf,
  Apple,
  Sun,
  Search,
  Cpu,
  ShieldCheck,
  Stethoscope,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { AMRITVEDA_SYMPTOMS, type SymptomDefinition } from "@shared/symptoms";

const CATEGORIES = [
  "All",
  "Dermatological",
  "Digestive",
  "Respiratory",
  "Musculoskeletal",
  "Neurological",
  "Fever & Systemic",
  "Urinary & Metabolic",
] as const;

const DOSHA_BADGE: Record<string, string> = {
  Vata: "bg-amber-100 text-amber-800 border-amber-300",
  Pitta: "bg-orange-100 text-orange-800 border-orange-300",
  Kapha: "bg-emerald-100 text-emerald-800 border-emerald-300",
  Tridoshic: "bg-purple-100 text-purple-800 border-purple-300",
};

export default function DiseasePrediction() {
  const [selected, setSelected] = useState<Set<string>>(new Set(["joint_pain", "knee_pain"]));
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [customInput, setCustomInput] = useState("");
  const predictMutation = usePredictDisease();

  const toggleSymptom = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const addCustom = () => {
    const parts = customInput.split(",").map((s) => s.trim().toLowerCase()).filter((s) => s.length > 0);
    if (parts.length === 0) return;
    setSelected((prev) => {
      const next = new Set(prev);
      parts.forEach((p) => next.add(p));
      return next;
    });
    setCustomInput("");
  };

  const clearAll = () => setSelected(new Set());

  const filteredSymptoms = useMemo(() => {
    return AMRITVEDA_SYMPTOMS.filter((sym) => {
      const matchesCategory = activeCategory === "All" || sym.category === activeCategory;
      const matchesSearch =
        searchQuery.trim() === "" ||
        sym.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sym.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const handlePredict = () => {
    if (selected.size === 0) return;
    predictMutation.mutate(Array.from(selected));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-16 px-4">
      {/* Header */}
      <header className="text-center pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 text-xs font-semibold uppercase tracking-wider mb-3">
          <Cpu className="w-3.5 h-3.5" />
          <span>Dual-Engine AI: Trained ML Model + Groq AI</span>
        </div>
        <h1 className="text-4xl font-display font-bold text-foreground tracking-tight mb-2">
          Ayurvedic Diagnostic Assessment
        </h1>
        <p className="text-muted-foreground text-base max-w-2xl mx-auto leading-relaxed">
          Select clinical symptoms for instant classification by our dedicated Random Forest ML model,
          synthesized with Groq AI for personalized Ayurvedic therapeutic guidance.
        </p>
      </header>

      {/* Selected Symptoms Bar */}
      <div className="bg-card/70 backdrop-blur-md rounded-2xl border border-border p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
            <h2 className="text-sm font-bold text-foreground">
              Selected Symptoms ({selected.size})
            </h2>
          </div>
          {selected.size > 0 && (
            <button
              onClick={clearAll}
              className="text-xs text-muted-foreground hover:text-destructive transition-colors font-medium"
            >
              Clear All
            </button>
          )}
        </div>

        {selected.size === 0 ? (
          <p className="text-xs text-muted-foreground italic">
            No symptoms selected yet. Pick symptoms below or use search to begin analysis.
          </p>
        ) : (
          <div className="flex flex-wrap gap-2 pt-1">
            {Array.from(selected).map((symptomId) => {
              const def = AMRITVEDA_SYMPTOMS.find((s) => s.id === symptomId);
              const label = def ? def.label : symptomId.replace(/_/g, " ");
              return (
                <span
                  key={symptomId}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 text-white text-xs rounded-full font-medium shadow-sm"
                >
                  {label}
                  <button
                    onClick={() => toggleSymptom(symptomId)}
                    className="hover:opacity-75 transition-opacity"
                    title="Remove"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              );
            })}
          </div>
        )}
      </div>

      {/* Symptom Explorer */}
      <div className="bg-card rounded-2xl border border-border p-6 shadow-sm space-y-5">
        <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search 132 symptoms (e.g. joint pain, fever, acidity, cough, rash)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick add custom */}
          <div className="flex gap-2">
            <input
              placeholder="Add symptom keyword..."
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addCustom()}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            <Button size="sm" variant="outline" onClick={addCustom} className="rounded-xl text-xs px-3">
              Add
            </Button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? "bg-emerald-700 text-white shadow-sm"
                  : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Symptom Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-80 overflow-y-auto p-1 pr-2">
          {filteredSymptoms.map((sym) => {
            const isSelected = selected.has(sym.id);
            return (
              <button
                key={sym.id}
                onClick={() => toggleSymptom(sym.id)}
                className={`px-3 py-2 text-left text-xs rounded-xl border font-medium transition-all flex items-center justify-between gap-1.5 ${
                  isSelected
                    ? "bg-emerald-700 text-white border-emerald-700 shadow-sm"
                    : "bg-background hover:bg-emerald-50/50 hover:border-emerald-300 text-foreground border-border/80"
                }`}
              >
                <span className="truncate">{sym.label}</span>
                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />}
              </button>
            );
          })}
        </div>

        {filteredSymptoms.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No symptoms matched "{searchQuery}". Try a different keyword or add it manually above.
          </div>
        )}
      </div>

      {/* Action Button */}
      <Button
        onClick={handlePredict}
        disabled={predictMutation.isPending || selected.size === 0}
        className="w-full h-14 rounded-2xl text-base font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-lg shadow-emerald-900/10 transition-all"
        data-testid="button-predict"
      >
        {predictMutation.isPending ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Analyzing with ML Model & Groq AI Orchestration...
          </>
        ) : (
          <>
            <Sparkles className="w-5 h-5 mr-2" />
            Analyze {selected.size} Symptoms with AmritVeda AI
          </>
        )}
      </Button>

      {/* Error Message */}
      {predictMutation.error instanceof Error && (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <span>{predictMutation.error.message}</span>
        </div>
      )}

      {/* Results View */}
      <AnimatePresence>
        {predictMutation.data && (
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="space-y-6 pt-2"
          >
            {/* Primary Result Banner */}
            <div className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                <Leaf className="w-64 h-64 text-white" />
              </div>

              <div className="relative z-10 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-emerald-200 border border-white/15 text-xs font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
                    <span>{predictMutation.data.modelInfo?.status || "Trained Machine Learning Model Verified"}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {predictMutation.data.doshaImbalance && (
                      <span className={`px-3 py-1 rounded-full text-xs font-bold border ${DOSHA_BADGE[predictMutation.data.doshaImbalance] || "bg-white/20 text-white"}`}>
                        {predictMutation.data.doshaImbalance} Imbalance
                      </span>
                    )}
                    <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      {predictMutation.data.confidence} Confidence
                    </span>
                  </div>
                </div>

                <div>
                  <p className="text-emerald-300 text-xs uppercase tracking-wider font-semibold mb-1">
                    Diagnosed Condition (Supervised ML Classifier)
                  </p>
                  <h2 className="text-3xl md:text-4xl font-display font-bold text-white">
                    {predictMutation.data.predictedDisease}
                  </h2>
                </div>

                {predictMutation.data.description && (
                  <p className="text-emerald-100/90 text-sm md:text-base leading-relaxed max-w-3xl">
                    {predictMutation.data.description}
                  </p>
                )}

                {/* Top candidate differential diagnoses */}
                {predictMutation.data.topCandidates && predictMutation.data.topCandidates.length > 1 && (
                  <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-2 text-xs text-emerald-200">
                    <span className="font-semibold text-emerald-300">Differential Candidates:</span>
                    {predictMutation.data.topCandidates.map((cand: any, idx: number) => (
                      <span key={idx} className="px-2.5 py-0.5 rounded-md bg-white/10 border border-white/10">
                        {cand.disease} ({cand.confidenceFormatted})
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Treatment Cards Grid */}
            <div className="grid md:grid-cols-2 gap-5">
              {/* Remedies */}
              <div className="bg-card rounded-2xl border border-border p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-lg text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-emerald-600" />
                  Ayurvedic Herbal Remedies
                </h3>
                <ul className="space-y-3">
                  {(predictMutation.data.remedies || []).map((r: string, i: number) => (
                    <li key={i} className="flex gap-3 text-sm text-muted-foreground leading-relaxed">
                      <span className="w-5 h-5 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Foods */}
              <div className="bg-card rounded-2xl border border-border p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-lg text-amber-800 dark:text-amber-400 flex items-center gap-2">
                  <Apple className="w-5 h-5 text-amber-600" />
                  Dietary & Nutrition Plan (Ahara)
                </h3>
                <ul className="space-y-3">
                  {(predictMutation.data.foods || []).map((f: string, i: number) => (
                    <li key={i} className="flex gap-3 text-sm text-muted-foreground leading-relaxed">
                      <span className="w-5 h-5 bg-amber-500/10 text-amber-700 dark:text-amber-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        •
                      </span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Lifestyle */}
              <div className="bg-card rounded-2xl border border-border p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-lg text-teal-800 dark:text-teal-400 flex items-center gap-2">
                  <Sun className="w-5 h-5 text-teal-600" />
                  Daily Routine & Lifestyle (Dinacharya)
                </h3>
                <ul className="space-y-3">
                  {(predictMutation.data.lifestyle || []).map((l: string, i: number) => (
                    <li key={i} className="flex gap-3 text-sm text-muted-foreground leading-relaxed">
                      <span className="w-5 h-5 bg-teal-500/10 text-teal-700 dark:text-teal-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        ✓
                      </span>
                      <span>{l}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Yoga & Pranayama */}
              <div className="bg-card rounded-2xl border border-border p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-lg text-purple-800 dark:text-purple-400 flex items-center gap-2">
                  <span className="text-base">🧘</span>
                  Therapeutic Yoga & Pranayama
                </h3>
                <ul className="space-y-3">
                  {(predictMutation.data.yogaPoses || []).map((y: string, i: number) => (
                    <li key={i} className="flex gap-3 text-sm text-muted-foreground leading-relaxed">
                      <span className="w-5 h-5 bg-purple-500/10 text-purple-700 dark:text-purple-400 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        🧘
                      </span>
                      <span>{y}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Contraindications / Avoid */}
            {predictMutation.data.avoid && predictMutation.data.avoid.length > 0 && (
              <div className="bg-red-500/5 rounded-2xl border border-red-500/20 p-6 space-y-3">
                <h4 className="font-bold text-sm text-red-700 dark:text-red-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  Practices & Foods to Avoid (Pathya-Apathya)
                </h4>
                <div className="flex flex-wrap gap-2">
                  {predictMutation.data.avoid.map((item: string, i: number) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 bg-red-100 dark:bg-red-950/40 text-red-800 dark:text-red-300 text-xs rounded-full border border-red-200 dark:border-red-900/50"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Medical Disclaimer */}
            <div className="bg-muted/40 rounded-2xl border border-border p-4 text-center">
              <p className="text-xs text-muted-foreground flex items-center justify-center gap-1.5 leading-relaxed">
                <Info className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  {predictMutation.data.disclaimer ||
                    "This clinical assessment is generated for wellness and educational purposes only. Always consult a qualified Ayurvedic physician or medical professional."}
                </span>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
