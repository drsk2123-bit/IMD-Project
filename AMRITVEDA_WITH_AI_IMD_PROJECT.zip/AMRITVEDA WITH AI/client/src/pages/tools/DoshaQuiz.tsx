import { useState } from "react";
import { useAnalyzeDosha } from "@/hooks/use-ayurveda";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Stethoscope, Loader2, ArrowRight, Wind, Flame, Droplets, ChevronRight, ChevronLeft } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";

const QUESTIONS = [
  {
    id: "q1",
    category: "Body & Appearance",
    question: "How would you describe your body frame?",
    options: [
      { value: "thin", label: "Thin, bony, light — difficult to gain weight", dosha: "V" },
      { value: "medium", label: "Medium, well-proportioned, muscular build", dosha: "P" },
      { value: "large", label: "Broad, heavy, sturdy — easy to gain weight", dosha: "K" },
    ],
  },
  {
    id: "q2",
    category: "Skin",
    question: "What best describes your skin?",
    options: [
      { value: "dry", label: "Dry, rough, thin, cracks easily — tends to feel cold", dosha: "V" },
      { value: "sensitive", label: "Sensitive, prone to redness, acne or rashes, feels warm", dosha: "P" },
      { value: "oily", label: "Oily, smooth, thick, cool and moist to touch", dosha: "K" },
    ],
  },
  {
    id: "q3",
    category: "Hair",
    question: "How would you describe your hair naturally?",
    options: [
      { value: "variable", label: "Dry, thin, brittle, frizzy or wiry", dosha: "V" },
      { value: "focused", label: "Fine, oily, prone to early greying or hair loss", dosha: "P" },
      { value: "steady", label: "Thick, wavy, lustrous, slightly oily", dosha: "K" },
    ],
  },
  {
    id: "q4",
    category: "Digestion",
    question: "How is your digestion typically?",
    options: [
      { value: "irregular", label: "Irregular — sometimes strong, sometimes weak. Prone to gas, bloating", dosha: "V" },
      { value: "sharp", label: "Strong and intense — get very hungry, irritable if meals are skipped", dosha: "P" },
      { value: "slow", label: "Slow and steady — can skip meals easily, feel heavy after eating", dosha: "K" },
    ],
  },
  {
    id: "q5",
    category: "Sleep",
    question: "How do you typically sleep?",
    options: [
      { value: "light", label: "Light sleeper — waking up easily, sometimes insomnia", dosha: "V" },
      { value: "moderate", label: "Moderate sleep — wake up easily but sleep well", dosha: "P" },
      { value: "deep", label: "Deep, heavy sleeper — love sleeping, hard to wake up", dosha: "K" },
    ],
  },
  {
    id: "q6",
    category: "Energy & Activity",
    question: "How would you describe your energy levels?",
    options: [
      { value: "creative", label: "Burst of energy then quick fatigue — enthusiastic starter but tires fast", dosha: "V" },
      { value: "competitive", label: "Driven and focused — medium-high sustained energy, goal-oriented", dosha: "P" },
      { value: "methodical", label: "Slow to start but steady — great endurance once going", dosha: "K" },
    ],
  },
  {
    id: "q7",
    category: "Emotions & Mind",
    question: "Under stress, you tend to:",
    options: [
      { value: "anxious", label: "Feel anxious, worried, overwhelmed, fearful", dosha: "V" },
      { value: "angry", label: "Get irritable, impatient, critical or angry", dosha: "P" },
      { value: "withdrawn", label: "Become withdrawn, stubborn, possessive or comfort-seeking", dosha: "K" },
    ],
  },
  {
    id: "q8",
    category: "Memory & Learning",
    question: "How do you learn and remember things?",
    options: [
      { value: "fast", label: "Learn quickly but forget quickly — scattered mind, many ideas", dosha: "V" },
      { value: "oily_pitta", label: "Quick to learn, sharp memory — analytical and precise", dosha: "P" },
      { value: "heavy", label: "Slow to learn but never forget — excellent long-term memory", dosha: "K" },
    ],
  },
  {
    id: "q9",
    category: "Temperature",
    question: "What temperature do you prefer?",
    options: [
      { value: "cold", label: "Dislike cold and wind — prefer warmth and sunshine", dosha: "V" },
      { value: "warm", label: "Dislike heat and bright sun — prefer cool environments", dosha: "P" },
      { value: "moist", label: "Dislike cold, damp weather — prefer dry, warm conditions", dosha: "K" },
    ],
  },
  {
    id: "q10",
    category: "Speech & Communication",
    question: "How do you typically communicate?",
    options: [
      { value: "flexible", label: "Talk quickly, change topics, lots of ideas, sometimes hard to follow", dosha: "V" },
      { value: "focused",  label: "Direct, precise, articulate — can be sharp or cutting", dosha: "P" },
      { value: "steady", label: "Speak slowly and deliberately — calm, soothing voice", dosha: "K" },
    ],
  },
  {
    id: "q11",
    category: "Appetite",
    question: "How would you describe your appetite?",
    options: [
      { value: "variable", label: "Variable — sometimes very hungry, other times forget to eat", dosha: "V" },
      { value: "sharp", label: "Always hungry at meals — strong appetite, irritable if hungry", dosha: "P" },
      { value: "slow", label: "Moderate appetite — can easily skip meals without discomfort", dosha: "K" },
    ],
  },
  {
    id: "q12",
    category: "Natural Tendencies",
    question: "Which best describes your natural lifestyle preference?",
    options: [
      { value: "creative", label: "Creative, expressive, adventurous — love change and variety", dosha: "V" },
      { value: "competitive", label: "Ambitious, organized, leadership-driven — love challenges", dosha: "P" },
      { value: "methodical", label: "Stable, nurturing, routine-loving — value comfort and security", dosha: "K" },
    ],
  },
];

const DOSHA_COLORS = {
  Vata: { bg: "bg-blue-500/10", text: "text-blue-600", border: "border-blue-200", icon: Wind, gradient: "from-blue-500 to-indigo-500" },
  Pitta: { bg: "bg-orange-500/10", text: "text-orange-600", border: "border-orange-200", icon: Flame, gradient: "from-orange-500 to-red-500" },
  Kapha: { bg: "bg-green-500/10", text: "text-green-600", border: "border-green-200", icon: Droplets, gradient: "from-green-500 to-teal-500" },
};

export default function DoshaQuiz() {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentPage, setCurrentPage] = useState(0);
  const doshaMutation = useAnalyzeDosha();

  const questionsPerPage = 4;
  const totalPages = Math.ceil(QUESTIONS.length / questionsPerPage);
  const pageQuestions = QUESTIONS.slice(currentPage * questionsPerPage, (currentPage + 1) * questionsPerPage);
  const answeredOnPage = pageQuestions.filter((q) => answers[q.id]).length;
  const allPageAnswered = answeredOnPage === pageQuestions.length;
  const isLastPage = currentPage === totalPages - 1;
  const totalAnswered = Object.keys(answers).length;
  const progress = (totalAnswered / QUESTIONS.length) * 100;

  const handleSubmit = () => {
    if (Object.keys(answers).length < QUESTIONS.length) return;
    doshaMutation.mutate(answers);
  };

  if (doshaMutation.data) {
    const d = doshaMutation.data;
    const doshaName = d.dosha as keyof typeof DOSHA_COLORS;
    const colors = DOSHA_COLORS[doshaName] || DOSHA_COLORS.Vata;
    const Icon = colors.icon;
    const scores = d.scores || {};
    const totalScore = (Object.values(scores) as number[]).reduce((a, b) => a + b, 0) || 1;

    return (
      <div className="max-w-3xl mx-auto pb-12">
        <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
          <div className={`bg-gradient-to-br ${colors.gradient} rounded-3xl p-8 text-white text-center shadow-xl`}>
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon className="w-10 h-10" />
            </div>
            <p className="text-white/80 font-medium uppercase tracking-widest text-sm mb-2">Your Dominant Dosha</p>
            <h1 className="text-6xl font-bold mb-3">{d.dosha}</h1>
            <p className="text-white/90 text-lg max-w-xl mx-auto leading-relaxed">{d.description}</p>
          </div>

          {/* Dosha Scores */}
          <div className="bg-card rounded-2xl border border-border p-6">
            <h3 className="font-bold text-lg mb-4">Your Constitution Breakdown</h3>
            <div className="space-y-4">
              {(["vata", "pitta", "kapha"] as const).map((d2) => {
                const pct = Math.round(((scores[d2] || 0) / totalScore) * 100);
                const c = DOSHA_COLORS[d2.charAt(0).toUpperCase() + d2.slice(1) as keyof typeof DOSHA_COLORS];
                return (
                  <div key={d2}>
                    <div className="flex justify-between text-sm font-medium mb-1">
                      <span className="capitalize">{d2}</span>
                      <span className={c?.text}>{pct}%</span>
                    </div>
                    <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full rounded-full bg-gradient-to-r ${c?.gradient}`} style={{ width: `${pct}%`, transition: "width 1s ease" }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary inline-block" /> Lifestyle Advice
              </h3>
              <ul className="space-y-2">
                {(d.lifestyleAdvice || []).map((item: string, i: number) => (
                  <li key={i} className="flex gap-2 text-muted-foreground text-sm leading-relaxed">
                    <span className="text-primary mt-1 shrink-0">•</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent inline-block" /> Diet & Nutrition
              </h3>
              <ul className="space-y-2">
                {(d.recommendations || []).map((item: string, i: number) => (
                  <li key={i} className="flex gap-2 text-muted-foreground text-sm leading-relaxed">
                    <span className="text-accent mt-1 shrink-0">•</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <h3 className="font-bold text-lg">Herbs & Supplements</h3>
              <ul className="space-y-2">
                {(d.herbsAndSupplements || []).map((item: string, i: number) => (
                  <li key={i} className="flex gap-2 text-muted-foreground text-sm leading-relaxed">
                    <span className="text-green-600 mt-1 shrink-0">🌿</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <h3 className="font-bold text-lg">Yoga & Daily Routine</h3>
              <ul className="space-y-2">
                {(d.yogaPoses || []).concat(d.dailyRoutine || []).slice(0, 8).map((item: string, i: number) => (
                  <li key={i} className="flex gap-2 text-muted-foreground text-sm leading-relaxed">
                    <span className="text-blue-600 mt-1 shrink-0">🧘</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {d.avoid && d.avoid.length > 0 && (
            <div className="bg-red-50 dark:bg-red-950/20 rounded-2xl border border-red-200 dark:border-red-900/40 p-6">
              <h3 className="font-bold text-lg text-red-700 dark:text-red-400 mb-3">⚠️ Things to Avoid</h3>
              <div className="flex flex-wrap gap-2">
                {(d.avoid || []).map((item: string, i: number) => (
                  <span key={i} className="px-3 py-1.5 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-sm rounded-full">{item}</span>
                ))}
              </div>
            </div>
          )}

          <Button className="w-full rounded-xl h-12" variant="outline" onClick={() => { doshaMutation.reset(); setAnswers({}); setCurrentPage(0); }}>
            Retake the Quiz
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <header className="text-center">
        <h1 className="text-4xl font-bold text-foreground mb-2">Discover Your Dosha</h1>
        <p className="text-muted-foreground">Answer {QUESTIONS.length} questions to identify your Ayurvedic constitution</p>
      </header>

      <div className="bg-card rounded-2xl border border-border p-4 flex items-center gap-4">
        <Progress value={progress} className="flex-1 h-2" />
        <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">
          {totalAnswered}/{QUESTIONS.length} answered
        </span>
      </div>

      {doshaMutation.error instanceof Error && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {doshaMutation.error.message}
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="space-y-5"
        >
          {pageQuestions.map((q, idx) => (
            <div key={q.id} className="bg-card p-6 rounded-2xl border border-border shadow-sm">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full">{q.category}</span>
              </div>
              <h3 className="text-lg font-bold mb-4 text-foreground">
                <span className="text-primary mr-2">{currentPage * questionsPerPage + idx + 1}.</span>
                {q.question}
              </h3>
              <RadioGroup
                value={answers[q.id] || ""}
                onValueChange={(val) => setAnswers((prev) => ({ ...prev, [q.id]: val }))}
                className="space-y-3"
              >
                {q.options.map((opt) => (
                  <div
                    key={opt.value}
                    className={`flex items-start space-x-3 p-4 rounded-xl border transition-all cursor-pointer ${
                      answers[q.id] === opt.value ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:bg-muted/30 hover:border-primary/30"
                    }`}
                  >
                    <RadioGroupItem value={opt.value} id={`${q.id}-${opt.value}`} className="mt-0.5" />
                    <Label htmlFor={`${q.id}-${opt.value}`} className="flex-1 cursor-pointer text-sm leading-relaxed">
                      {opt.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          ))}
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between items-center pt-2">
        <Button
          variant="outline"
          onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
          disabled={currentPage === 0}
          className="rounded-xl h-12 px-6"
        >
          <ChevronLeft className="w-4 h-4 mr-1" /> Previous
        </Button>

        <span className="text-sm text-muted-foreground font-medium">
          Page {currentPage + 1} of {totalPages}
        </span>

        {isLastPage ? (
          <Button
            size="lg"
            onClick={handleSubmit}
            disabled={totalAnswered < QUESTIONS.length || doshaMutation.isPending}
            className="rounded-xl h-12 px-8 bg-primary"
          >
            {doshaMutation.isPending ? (
              <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Analyzing...</>
            ) : (
              <>Analyze My Dosha <ArrowRight className="ml-2 w-5 h-5" /></>
            )}
          </Button>
        ) : (
          <Button
            onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
            disabled={!allPageAnswered}
            className="rounded-xl h-12 px-6"
          >
            Next <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        )}
      </div>
    </div>
  );
}
