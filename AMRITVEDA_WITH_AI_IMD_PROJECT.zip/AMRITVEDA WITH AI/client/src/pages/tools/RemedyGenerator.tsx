import { useState } from "react";
import { useGenerateRemedy } from "@/hooks/use-ayurveda";
import { Button } from "@/components/ui/button";
import { Droplets, Leaf, ShieldAlert, Sparkles, Loader2, Coffee, Sun, Layers } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CONDITION_CATEGORIES = [
  {
    name: "Digestive Issues",
    icon: "🫃",
    conditions: ["Constipation", "Diarrhea", "Bloating & Gas", "Acid Reflux (GERD)", "Irritable Bowel Syndrome", "Indigestion", "Nausea", "Loss of Appetite", "Liver Weakness", "Hemorrhoids"],
  },
  {
    name: "Respiratory",
    icon: "🫁",
    conditions: ["Common Cold", "Cough", "Bronchitis", "Asthma", "Sinusitis", "Allergic Rhinitis", "Sore Throat", "Tonsillitis", "Chronic Cough", "Chest Congestion"],
  },
  {
    name: "Joints & Muscles",
    icon: "🦴",
    conditions: ["Arthritis", "Joint Pain", "Back Pain", "Muscle Stiffness", "Gout", "Sciatica", "Neck Pain", "Knee Pain", "Fibromyalgia", "Osteoporosis"],
  },
  {
    name: "Skin & Hair",
    icon: "🌿",
    conditions: ["Acne", "Eczema", "Psoriasis", "Dry Skin", "Hair Fall", "Dandruff", "Premature Greying", "Skin Rashes", "Dark Spots", "Stretch Marks"],
  },
  {
    name: "Mental Wellness",
    icon: "🧠",
    conditions: ["Anxiety", "Depression", "Insomnia", "Stress", "Brain Fog", "Poor Memory", "ADHD", "Burnout", "Mood Swings", "Low Confidence"],
  },
  {
    name: "Metabolic & Hormonal",
    icon: "⚡",
    conditions: ["Diabetes", "Obesity", "Thyroid Issues", "PCOS", "High Cholesterol", "High Blood Pressure", "Anemia", "Low Immunity", "Chronic Fatigue", "Hormonal Imbalance"],
  },
  {
    name: "Urinary & Reproductive",
    icon: "💧",
    conditions: ["UTI", "Kidney Stones", "Enlarged Prostate", "Menstrual Cramps", "Infertility", "Low Libido", "Menopausal Symptoms", "Leucorrhea", "Prostatitis", "Bed Wetting"],
  },
  {
    name: "Eyes, Ears & Oral",
    icon: "👁️",
    conditions: ["Eye Strain", "Dry Eyes", "Ear Infections", "Tinnitus", "Toothache", "Gum Disease", "Mouth Ulcers", "Bad Breath", "Vision Weakness", "Night Blindness"],
  },
];

export default function RemedyGenerator() {
  const [selectedConditions, setSelectedConditions] = useState<Set<string>>(new Set());
  const [customInput, setCustomInput] = useState("");
  const [activeTab, setActiveTab] = useState<"remedies" | "foods" | "practices">("remedies");
  const remedyMutation = useGenerateRemedy();

  const toggleCondition = (c: string) => {
    setSelectedConditions((prev) => {
      const next = new Set(prev);
      if (next.has(c)) next.delete(c);
      else next.add(c);
      return next;
    });
  };

  const addCustom = () => {
    const parts = customInput.split(",").map((s) => s.trim()).filter(Boolean);
    if (!parts.length) return;
    setSelectedConditions((prev) => { const n = new Set(prev); parts.forEach((p) => n.add(p)); return n; });
    setCustomInput("");
  };

  const handleGenerate = () => {
    if (selectedConditions.size === 0) return;
    remedyMutation.mutate(Array.from(selectedConditions));
  };

  const data = remedyMutation.data;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <header className="flex items-center gap-5 mb-6">
        <div className="w-16 h-16 bg-green-600/10 text-green-600 rounded-2xl flex items-center justify-center shrink-0">
          <Droplets className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-1">Natural Remedies</h1>
          <p className="text-muted-foreground text-lg">Select your condition for Ayurvedic herbal remedies & healing guidance</p>
        </div>
      </header>

      {/* Selected */}
      {selectedConditions.size > 0 && (
        <div className="bg-green-50 dark:bg-green-950/20 rounded-2xl border border-green-200 dark:border-green-900/40 p-4">
          <p className="text-sm font-semibold text-green-700 dark:text-green-400 mb-2">Selected ({selectedConditions.size})</p>
          <div className="flex flex-wrap gap-2">
            {Array.from(selectedConditions).map((c) => (
              <button
                key={c}
                onClick={() => toggleCondition(c)}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-600 text-white text-sm rounded-full font-medium hover:bg-green-700 transition-colors"
              >
                {c} ×
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Condition Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {CONDITION_CATEGORIES.map((cat) => (
          <div key={cat.name} className="bg-card rounded-2xl border border-border p-5">
            <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
              <span>{cat.icon}</span> {cat.name}
            </h3>
            <div className="flex flex-wrap gap-2">
              {cat.conditions.map((c) => (
                <button
                  key={c}
                  onClick={() => toggleCondition(c)}
                  className={`px-3 py-1.5 text-xs rounded-full border font-medium transition-all ${
                    selectedConditions.has(c)
                      ? "bg-primary text-white border-primary"
                      : "bg-muted/50 text-foreground border-border hover:border-primary/50 hover:bg-primary/5"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Custom Input */}
      <div className="bg-card rounded-2xl border border-border p-4 flex gap-3 items-center">
        <input
          className="flex-1 bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground"
          placeholder="Add custom condition or symptom (comma-separated)..."
          value={customInput}
          onChange={(e) => setCustomInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addCustom()}
        />
        <Button size="sm" variant="outline" onClick={addCustom} className="shrink-0 rounded-lg">Add</Button>
      </div>

      <Button
        onClick={handleGenerate}
        disabled={remedyMutation.isPending || selectedConditions.size === 0}
        className="w-full h-14 rounded-xl text-lg bg-primary"
        data-testid="button-generate-remedy"
      >
        {remedyMutation.isPending ? (
          <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating Remedies...</>
        ) : (
          <><Sparkles className="w-5 h-5 mr-2" /> Generate Ayurvedic Remedies</>
        )}
      </Button>

      {remedyMutation.error instanceof Error && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {remedyMutation.error.message}
        </div>
      )}

      <AnimatePresence>
        {data && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            {/* Condition Header */}
            <div className="bg-gradient-to-r from-green-600/10 to-teal-600/10 rounded-2xl border border-green-200 dark:border-green-900/40 p-6 flex items-center gap-4">
              <div className="w-12 h-12 bg-green-600/20 text-green-600 rounded-xl flex items-center justify-center">
                <Leaf className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Remedies For</p>
                <h2 className="text-2xl font-bold text-foreground">{data.condition || Array.from(selectedConditions).join(", ")}</h2>
              </div>
            </div>

            {/* Tab Nav */}
            <div className="flex gap-1 bg-muted/50 p-1 rounded-xl w-fit">
              {[
                { key: "remedies", label: "Herbs & Remedies", icon: Leaf },
                { key: "foods", label: "Healing Foods", icon: Coffee },
                { key: "practices", label: "Yoga & Practices", icon: Sun },
              ].map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeTab === key ? "bg-white dark:bg-card shadow-sm text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="w-4 h-4" /> {label}
                </button>
              ))}
            </div>

            {activeTab === "remedies" && (
              <div className="grid md:grid-cols-2 gap-5">
                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-green-700">
                    <Leaf className="w-5 h-5" /> Herbal Remedies
                  </h3>
                  <div className="space-y-3">
                    {(data.remedies || []).map((item: string, i: number) => (
                      <div key={i} className="p-3.5 bg-green-50 dark:bg-green-950/20 rounded-xl text-sm text-foreground leading-relaxed border border-green-100 dark:border-green-900/30">
                        <span className="font-medium text-green-700 dark:text-green-400 mr-1">{i + 1}.</span> {item}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-teal-700">
                    <Layers className="w-5 h-5" /> Treatments & Therapies
                  </h3>
                  <ul className="space-y-3">
                    {(data.naturalTreatments || []).map((item: string, i: number) => (
                      <li key={i} className="flex gap-2.5 text-sm text-muted-foreground leading-relaxed">
                        <span className="text-teal-600 mt-0.5 shrink-0">•</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {data.oilsAndMassage && data.oilsAndMassage.length > 0 && (
                  <div className="bg-card rounded-2xl border border-border p-6 md:col-span-2">
                    <h3 className="font-bold text-lg mb-4">💆 Oils & Massage Therapy</h3>
                    <div className="grid sm:grid-cols-3 gap-3">
                      {data.oilsAndMassage.map((item: string, i: number) => (
                        <div key={i} className="p-3.5 bg-amber-50 dark:bg-amber-950/20 rounded-xl text-sm text-foreground leading-relaxed border border-amber-100 dark:border-amber-900/30">
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === "foods" && (
              <div className="grid md:grid-cols-2 gap-5">
                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-bold text-lg mb-4">🥗 Healing Foods</h3>
                  <ul className="space-y-3">
                    {(data.healingFoods || []).map((item: string, i: number) => (
                      <li key={i} className="flex gap-2.5 text-sm text-muted-foreground leading-relaxed">
                        <span className="text-orange-500 mt-0.5 shrink-0">🍃</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-bold text-lg mb-4">☕ Herbal Teas & Kadhas</h3>
                  <ul className="space-y-3">
                    {(data.herbalTeas || []).map((item: string, i: number) => (
                      <li key={i} className="flex gap-2.5 text-sm text-muted-foreground leading-relaxed">
                        <span className="text-brown-500 mt-0.5 shrink-0">🫖</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {activeTab === "practices" && (
              <div className="bg-card rounded-2xl border border-border p-6">
                <h3 className="font-bold text-lg mb-4">🧘 Yoga & Pranayama Practices</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {(data.yogaAndPranayama || []).map((item: string, i: number) => (
                    <div key={i} className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-xl text-sm text-foreground leading-relaxed border border-blue-100 dark:border-blue-900/30">
                      <span className="font-medium text-blue-700 dark:text-blue-400 block mb-1">Practice {i + 1}</span>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Warnings */}
            <div className="bg-red-50 dark:bg-red-950/20 rounded-2xl border border-red-200 dark:border-red-900/40 p-6">
              <h3 className="font-bold text-red-700 dark:text-red-400 mb-3 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" /> Important Warnings & Precautions
              </h3>
              <ul className="space-y-2">
                {(data.warnings || []).map((w: string, i: number) => (
                  <li key={i} className="text-sm text-red-800 dark:text-red-300 leading-relaxed flex gap-2">
                    <span className="shrink-0">⚠️</span> {w}
                  </li>
                ))}
              </ul>
            </div>

            <p className="text-xs text-muted-foreground text-center">
              This information is for educational purposes only. Always consult a qualified Ayurvedic practitioner before starting any treatment.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
