# AmritVeda Machine Learning Model Integration Directory

This directory is designated for your trained machine learning model artifacts.

## How to Integrate Your Trained Model

1. **Place your trained model file here**:
   - Supported extensions: `.pkl`, `.joblib`, `.pt`, `.pth`, `.onnx`, `.h5`, `.keras`
   - Default filename: `disease_model.pkl` (or configure via `MODEL_PATH` in `.env`)

2. **Add Model Metadata (`metadata.json`)**:
   Provide the list of symptom features your model was trained on, and the class labels:
   ```json
   {
     "framework": "scikit-learn",
     "version": "1.0",
     "features": [
       "headache",
       "fever",
       "joint_pain",
       "acidity",
       "dry_skin",
       "insomnia",
       "cough"
     ],
     "classes": [
       "Vata Vyadhi (Joint Disorder)",
       "Amlapitta (Hyperacidity)",
       "Pratishyaya (Rhinitis/Cold)",
       "Kasa (Cough)",
       "Jwara (Fever)"
     ]
   }
   ```

3. **Inference Pipeline**:
   The `predict.py` runner automatically handles:
   - Loading `.pkl` / `.joblib` files
   - Encoding user symptoms against feature vectors
   - Running `model.predict()` and `model.predict_proba()`
   - Returning genuine prediction and true confidence score

4. **Environment Variables**:
   In your `.env`:
   ```bash
   MODEL_ENABLED=true
   MODEL_PATH=./ml-model/disease_model.pkl
   MODEL_METADATA_PATH=./ml-model/metadata.json
   ```

5. **No Fake Predictions**:
   If the model file is not present, AmritVeda gracefully reports that custom ML artifacts are awaiting upload, and uses the Ayurvedic clinical knowledge base with Groq AI explanations without fabricating fake model outputs.

