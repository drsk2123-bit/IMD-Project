#!/usr/bin/env python3
"""
AmritVeda ML Inference Runner
Runs genuine inference on the trained Scikit-Learn RandomForestClassifier model.
"""

import sys
import os
import json
import warnings
import re

# Suppress sklearn unpickle/version warnings
warnings.filterwarnings("ignore")

def clean_feature_string(s: str) -> str:
    # Convert 'Joint Pain' -> 'joint_pain'
    s = s.strip().lower()
    s = re.sub(r'[\s\-]+', '_', s)
    s = re.sub(r'[^a-z0-9_]', '', s)
    return s

def main():
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: predict.py <model_path> '<symptoms_json_array>'"}))
        sys.exit(1)

    model_path = sys.argv[1]
    symptoms_raw = sys.argv[2]

    try:
        symptoms = json.loads(symptoms_raw)
        if not isinstance(symptoms, list):
            symptoms = [str(symptoms)]
    except Exception as e:
        print(json.dumps({"error": f"Invalid JSON for symptoms: {str(e)}"}))
        sys.exit(1)

    if not os.path.exists(model_path):
        print(json.dumps({"error": f"Model file not found at {model_path}"}))
        sys.exit(1)

    try:
        import joblib
        model = joblib.load(model_path)
    except Exception as e:
        try:
            import pickle
            with open(model_path, "rb") as f:
                model = pickle.load(f)
        except Exception as e2:
            print(json.dumps({"error": f"Failed to unpickle model: {str(e)} | {str(e2)}"}))
            sys.exit(1)

    # Get feature names from model or metadata
    if hasattr(model, "feature_names_in_"):
        feature_names = list(model.feature_names_in_)
    else:
        meta_path = os.path.join(os.path.dirname(model_path), "metadata.json")
        if os.path.exists(meta_path):
            with open(meta_path, "r") as f:
                feature_names = json.load(f).get("features", [])
        else:
            print(json.dumps({"error": "Model has no feature_names_in_ and metadata.json not found."}))
            sys.exit(1)

    # Clean user symptoms
    user_symptoms_clean = [clean_feature_string(s) for s in symptoms]

    # Build binary feature vector
    import pandas as pd
    import numpy as np

    feature_vector = {}
    matched_features = []

    for feat in feature_names:
        clean_feat = clean_feature_string(feat)
        # Check if any user symptom matches this feature
        is_active = 0
        for user_sym in user_symptoms_clean:
            if user_sym == clean_feat or user_sym in clean_feat or clean_feat in user_sym:
                is_active = 1
                matched_features.append(feat)
                break
        feature_vector[feat] = [is_active]

    df_input = pd.DataFrame(feature_vector, columns=feature_names)

    # Run genuine prediction
    try:
        probabilities = model.predict_proba(df_input)[0]
        max_idx = int(np.argmax(probabilities))
        confidence = float(probabilities[max_idx])

        if hasattr(model, "classes_"):
            predicted_disease = str(model.classes_[max_idx])
        else:
            predicted_disease = str(model.predict(df_input)[0])

        # Get top 3 candidate predictions with genuine probabilities
        top_indices = np.argsort(probabilities)[::-1][:3]
        top_candidates = [
            {
                "disease": str(model.classes_[idx]),
                "confidence": float(probabilities[idx]),
                "confidenceFormatted": f"{probabilities[idx] * 100:.1f}%"
            }
            for idx in top_indices if probabilities[idx] > 0.01
        ]

        output = {
            "predictedDisease": predicted_disease,
            "confidence": confidence,
            "confidenceFormatted": f"{confidence * 100:.1f}%",
            "matchedFeaturesCount": len(matched_features),
            "matchedFeatures": list(set(matched_features)),
            "topCandidates": top_candidates,
            "modelType": "RandomForestClassifier (AmritVeda Trained ML)"
        }
        print(json.dumps(output))
        sys.exit(0)

    except Exception as e:
        print(json.dumps({"error": f"Inference execution failed: {str(e)}"}))
        sys.exit(1)

if __name__ == "__main__":
    main()
