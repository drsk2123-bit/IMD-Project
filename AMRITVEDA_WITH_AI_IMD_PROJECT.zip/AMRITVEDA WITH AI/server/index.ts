import "dotenv/config";
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import net from "node:net";

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

function sanitizeForLogging(data: any): any {
  if (!data || typeof data !== "object") return data;
  if (Array.isArray(data)) return data.slice(0, 5).map(sanitizeForLogging);
  const sanitized: Record<string, any> = {};
  for (const [k, v] of Object.entries(data)) {
    if (["password", "token", "apikey", "secret"].some((s) => k.toLowerCase().includes(s))) {
      sanitized[k] = "[REDACTED]";
    } else if (typeof v === "object") {
      sanitized[k] = sanitizeForLogging(v);
    } else {
      sanitized[k] = v;
    }
  }
  return sanitized;
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(sanitizeForLogging(capturedJsonResponse))}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  app.use((err: any, _req: Request, res: Response, next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error("Internal Server Error:", err);

    if (res.headersSent) {
      return next(err);
    }

    return res.status(status).json({ message });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  const basePort = parseInt(process.env.PORT || "5001", 10);

  const findAvailablePort = async (preferredPort: number) => {
    if (process.env.PORT) {
      return preferredPort;
    }

    const isPortFree = (port: number) =>
      new Promise<boolean>((resolve) => {
        const tester = net.createServer();

        tester.once("error", () => resolve(false));
        tester.once("listening", () => {
          tester.close(() => resolve(true));
        });

        tester.listen(port, "0.0.0.0");
      });

    for (let port = preferredPort; port <= preferredPort + 5; port++) {
      if (await isPortFree(port)) {
        if (port !== preferredPort) {
          log(`port ${preferredPort} is busy, using port ${port}`);
        }
        return port;
      }
    }

    throw new Error(`No free port found between ${preferredPort} and ${preferredPort + 5}`);
  };

  const port = await findAvailablePort(basePort);
  const listenOptions: any = {
    port,
    host: "0.0.0.0",
  };

  if (process.platform !== "win32") {
    listenOptions.reusePort = true;
  }

  httpServer.listen(listenOptions, () => {
    log(`serving on port ${port}`);
  });
})();
