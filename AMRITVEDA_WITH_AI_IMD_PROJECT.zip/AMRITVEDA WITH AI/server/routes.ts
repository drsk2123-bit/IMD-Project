import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { groqService } from "./services/groq.service";
import { mlModelService } from "./services/ml.service";
import { aiOrchestrator } from "./services/orchestrator.service";

const JWT_SECRET = process.env.SESSION_SECRET || "amritveda_secret";

function getAIErrorResponse(err: unknown) {
  if (err instanceof Error) {
    if (err.message.toLowerCase().includes("fetch failed") || err.message.toLowerCase().includes("timeout")) {
      return {
        status: 504,
        message: "Unable to reach Groq AI. Please check your internet connection.",
      };
    }
    return {
      status: 502,
      message: err.message,
    };
  }
  return {
    status: 500,
    message: "An unexpected AI processing error occurred.",
  };
}

function authenticateToken(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) return res.status(401).json({ message: "No token provided" });
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(401).json({ message: "Invalid token" });
    (req as any).user = user;
    next();
  });
}

function extractJSONObject(text: string) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");

  if (start === -1 || end === -1 || end <= start) {
    throw new Error("AI response did not contain valid JSON.");
  }

  return text.slice(start, end + 1);
}

function sanitizeJSONString(jsonText: string) {
  let result = "";
  let inString = false;
  let escaping = false;

  for (const char of jsonText) {
    if (escaping) {
      result += char;
      escaping = false;
      continue;
    }

    if (char === "\\") {
      result += char;
      escaping = true;
      continue;
    }

    if (char === "\"") {
      result += char;
      inString = !inString;
      continue;
    }

    if (inString && (char === "\n" || char === "\r" || char === "\t")) {
      result += " ";
      continue;
    }

    result += char;
  }

  return result;
}

function scoreSymptoms(symptoms: string[]) {
  const normalized = symptoms.map((s) => s.toLowerCase());
  const scores = { vata: 0, pitta: 0, kapha: 0 };

  for (const symptom of normalized) {
    if (["anxiety", "insomnia", "constipation", "dry skin", "joint pain", "back pain", "brain fog", "brittle nails"].some((k) => symptom.includes(k))) scores.vata += 2;
    if (["acid reflux", "rashes", "acne", "itching", "fever", "sweating", "hair fall", "migraine"].some((k) => symptom.includes(k))) scores.pitta += 2;
    if (["weight gain", "cough", "sinusitis", "depression", "low energy", "frequent urination", "chills"].some((k) => symptom.includes(k))) scores.kapha += 2;
  }

  const ordered = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const top = ordered[0][0];
  const second = ordered[1][0];
  const close = ordered[0][1] > 0 && ordered[0][1] - ordered[1][1] <= 1;
  const dosha = close ? "Tridoshic" : top.charAt(0).toUpperCase() + top.slice(1);

  return { scores, dosha };
}

function buildDiseaseFallback(symptoms: string[]) {
  const normalized = symptoms.map((s) => s.toLowerCase());
  const { dosha } = scoreSymptoms(symptoms);
  const hasAny = (keywords: string[]) => normalized.some((symptom) => keywords.some((keyword) => symptom.includes(keyword)));

  const isRespiratory = hasAny(["cough", "shortness of breath", "chest tightness", "wheezing", "runny nose", "sore throat", "sneezing", "sinus", "asthma", "bronchitis"]);
  const isDigestive = hasAny(["bloating", "constipation", "diarrhea", "nausea", "acid reflux", "gas", "poor appetite", "vomiting", "stomach cramps", "indigestion"]);
  const isMusculoskeletal = hasAny(["joint pain", "back pain", "muscle stiffness", "neck pain", "weakness", "swollen joints", "knee pain", "muscle cramps", "frozen shoulder", "arthritis"]);
  const isNeurological = hasAny(["headache", "migraine", "dizziness", "insomnia", "anxiety", "brain fog", "numbness", "fatigue", "memory loss", "tremors"]);
  const isSkin = hasAny(["dry skin", "rashes", "acne", "itching", "eczema", "hair fall", "psoriasis", "dark circles", "pale skin", "brittle nails"]);
  const isGeneral = hasAny(["fever", "chills", "weight gain", "weight loss", "excessive thirst", "frequent urination", "sweating", "low immunity", "depression", "low energy"]);

  let predictedDisease = "General dosha imbalance";
  let description = `Based on the selected symptoms, this pattern most closely matches a ${dosha} imbalance in Ayurvedic assessment. Use this as a wellness guide rather than a medical diagnosis.`;
  let remedies = [
    "Sip warm water through the day to support digestion and circulation.",
    "Use ginger tea after meals in small amounts if it feels suitable for your body.",
    "Favor simple home-cooked meals over cold, processed, or heavy foods.",
    "Add turmeric and cumin to meals to support balanced digestion.",
    "Maintain regular sleep and meal timings for better dosha stability.",
    "Consult an Ayurvedic practitioner if symptoms are persistent or worsening.",
  ];
  let foods = [
    "Choose warm, freshly cooked meals over refrigerated foods.",
    "Include seasonal vegetables and easy-to-digest grains.",
    "Use light spices like cumin, coriander, and fennel.",
    "Avoid overeating and eat at regular times.",
    "Reduce packaged sugary foods and deep-fried items.",
    "Hydrate steadily rather than taking very cold drinks.",
  ];
  let lifestyle = [
    "Follow a consistent daily routine.",
    "Take a gentle walk after meals.",
    "Practice 10 minutes of mindful breathing each day.",
    "Prioritize adequate rest and lower screen exposure at night.",
  ];
  let yogaPoses = [
    "Cat-Cow for circulation and spinal ease.",
    "Child's Pose for calming the nervous system.",
    "Seated Twist for digestive support.",
  ];
  let avoid = [
    "Skipping meals",
    "Very late nights",
    "Excessively spicy or oily foods",
    "Long periods of unmanaged stress",
  ];

  if (isRespiratory) {
    predictedDisease = "Kapha respiratory imbalance";
    description = "These symptoms suggest congestion and heaviness that often resemble a Kapha-dominant respiratory pattern in Ayurveda. The focus should be on warming, clearing, and supporting easier breathing.";
    remedies = [
      "Drink tulsi-ginger tea warm to support the throat and chest.",
      "Use steam inhalation carefully for sinus and nasal congestion.",
      "Try warm salt-water gargles for throat comfort.",
      "Use turmeric in warm milk or water if it suits your body.",
      "Rest well and keep the chest and throat warm.",
      "Seek medical care if breathing becomes difficult or fever persists.",
    ];
    foods = [
      "Take warm soups and broths instead of heavy meals.",
      "Use garlic, ginger, and black pepper in moderation.",
      "Avoid cold drinks, ice cream, and refrigerated foods.",
      "Prefer light meals over fried or cheesy food.",
      "Sip warm water through the day.",
      "Choose cooked vegetables instead of heavy snacks.",
    ];
    lifestyle = [
      "Rest and avoid cold exposure.",
      "Sleep with the head slightly raised if congested.",
      "Use gentle walks to avoid sluggishness.",
      "Avoid forceful exercise during active symptoms.",
    ];
    yogaPoses = [
      "Supported Child's Pose for rest.",
      "Gentle chest openers for breathing comfort.",
      "Cat-Cow for circulation and mobility.",
    ];
    avoid = [
      "Cold drinks",
      "Heavy dairy during congestion",
      "Late nights",
      "Dusty or smoky environments",
    ];
  } else if (isDigestive) {
    predictedDisease = "Vata-Pitta digestive imbalance";
    description = "These symptoms point toward disturbed digestive fire and gut rhythm, commonly interpreted as a Vata-Pitta digestive imbalance. The focus should be on soothing, regular, easy-to-digest routines.";
    remedies = [
      "Use cumin-coriander-fennel tea after meals.",
      "Eat simple khichdi or rice-based meals while digestion settles.",
      "Take roasted fennel seeds after meals for bloating support.",
      "Use ginger in small amounts if appetite is low and heat is not excessive.",
      "Maintain regular meal timing every day.",
      "Consult a doctor if vomiting, dehydration, or severe pain occurs.",
    ];
    foods = [
      "Choose soft, freshly cooked foods.",
      "Use rice, mung dal, and cooked vegetables for easier digestion.",
      "Avoid very spicy, oily, and packaged food.",
      "Prefer warm water to cold drinks.",
      "Use light spices like cumin and fennel.",
      "Keep dinner lighter than lunch.",
    ];
    lifestyle = [
      "Eat on time and avoid skipping meals.",
      "Take a slow walk after meals.",
      "Avoid lying down immediately after eating.",
      "Reduce stress while eating and chew food well.",
    ];
    yogaPoses = [
      "Vajrasana after meals for a short time.",
      "Seated Twist for digestion.",
      "Apanasana for gas relief.",
    ];
    avoid = [
      "Overeating",
      "Cold drinks with meals",
      "Eating too fast",
      "Very late dinners",
    ];
  } else if (isMusculoskeletal) {
    predictedDisease = "Vata musculoskeletal imbalance";
    description = "Pain, stiffness, and cracking-type symptoms often suggest aggravated Vata affecting muscles and joints. Ayurveda usually emphasizes warmth, lubrication, mobility, and routine in such cases.";
    remedies = [
      "Use warm sesame oil massage over stiff areas if suitable.",
      "Add turmeric and dry ginger in cooking for warming support.",
      "Apply gentle heat to non-inflamed stiffness.",
      "Stay physically warm and avoid exposure to cold wind.",
      "Use light daily stretching rather than complete inactivity.",
      "Seek care for swelling, injury, numbness, or severe pain.",
    ];
    foods = [
      "Take warm soups and cooked meals.",
      "Use anti-inflammatory spices like turmeric and cumin.",
      "Avoid cold, dry, and very processed food.",
      "Hydrate regularly.",
      "Prefer freshly cooked foods over packaged snacks.",
      "Reduce excess sugar and deep-fried items.",
    ];
    lifestyle = [
      "Do gentle mobility work every day.",
      "Avoid sitting in one position for too long.",
      "Use heat therapy for stiffness when helpful.",
      "Prioritize regular sleep and recovery.",
    ];
    yogaPoses = [
      "Cat-Cow for spinal mobility.",
      "Supported Bridge for gentle strength.",
      "Child's Pose for relaxation and release.",
    ];
    avoid = [
      "Cold exposure",
      "Sudden heavy exercise",
      "Long immobility",
      "Skipping rest",
    ];
  } else if (isNeurological) {
    predictedDisease = "Vata nervous system imbalance";
    description = "Symptoms like anxiety, insomnia, dizziness, and brain fog often reflect an aggravated Vata pattern involving the nervous system. The main goal is calming, grounding, and restoring rhythm.";
    remedies = [
      "Use warm sesame oil foot massage before sleep.",
      "Drink calming tulsi tea or warm milk with nutmeg if suitable.",
      "Practice slow breathing in the evening.",
      "Keep meals and sleep on a regular schedule.",
      "Reduce caffeine and overstimulation late in the day.",
      "Get medical attention for severe headaches, fainting, or neurological changes.",
    ];
    foods = [
      "Choose warm, grounding meals instead of dry snacks.",
      "Use soups, khichdi, oats, and cooked grains.",
      "Avoid excessive caffeine and energy drinks.",
      "Keep blood sugar stable with regular meals.",
      "Take easy-to-digest, nourishing foods.",
      "Avoid very cold or irregular eating patterns.",
    ];
    lifestyle = [
      "Sleep and wake at fixed times.",
      "Reduce screen exposure before bed.",
      "Take breaks during stressful work.",
      "Practice grounding breathwork every day.",
    ];
    yogaPoses = [
      "Legs-Up-the-Wall for calming.",
      "Child's Pose for nervous system relief.",
      "Seated Forward Bend for grounding.",
    ];
    avoid = [
      "Late-night work",
      "Too much caffeine",
      "Irregular routine",
      "Overstimulation before sleep",
    ];
  } else if (isSkin) {
    predictedDisease = "Pitta skin imbalance";
    description = "Skin irritation, redness, rashes, and heat signs often point to a Pitta-dominant skin imbalance in Ayurveda. The focus is usually on cooling, gentle skin care, and reducing inflammatory triggers.";
    remedies = [
      "Use cooling foods and gentle skin care.",
      "Apply aloe vera or coconut oil externally only if your skin tolerates it.",
      "Use turmeric in food to support inflammatory balance.",
      "Reduce scratching and harsh skin products.",
      "Support digestion since skin often reflects internal imbalance.",
      "Consult a dermatologist for severe or infected skin conditions.",
    ];
    foods = [
      "Favor cooling, simple foods.",
      "Use cucumber, gourds, and cooked greens.",
      "Reduce very spicy, fried, and sugary foods.",
      "Stay hydrated steadily.",
      "Use coriander and fennel in meals.",
      "Avoid obvious dietary triggers that worsen flare-ups.",
    ];
    lifestyle = [
      "Avoid overheating and harsh sun when flare-ups are active.",
      "Use simple fragrance-free skin care.",
      "Keep sleep regular to reduce inflammatory stress.",
      "Track flare-up triggers from food and stress.",
    ];
    yogaPoses = [
      "Gentle twists for digestion support.",
      "Restorative yoga for stress reduction.",
      "Forward bends for cooling and calm.",
    ];
    avoid = [
      "Very spicy foods",
      "Harsh cosmetic products",
      "Excess heat exposure",
      "Picking or scratching lesions",
    ];
  } else if (isGeneral) {
    predictedDisease = "Kapha metabolic imbalance";
    description = "General symptoms such as heaviness, low energy, weight changes, and low immunity often reflect a broader Kapha or metabolic imbalance. Ayurveda usually emphasizes lighter food, movement, and regular daily rhythm.";
    remedies = [
      "Use warm water through the day instead of cold drinks.",
      "Include ginger, turmeric, and cumin in regular cooking.",
      "Take a brisk daily walk if energy permits.",
      "Reduce heavy, oily, and sugary foods.",
      "Keep meal timing and sleep timing steady.",
      "Seek medical testing for persistent fatigue, weight changes, or thirst issues.",
    ];
    foods = [
      "Choose lighter, freshly cooked meals.",
      "Use whole foods instead of packaged snacks.",
      "Reduce added sugar and fried foods.",
      "Favor cooked vegetables and lighter dals.",
      "Avoid frequent overeating.",
      "Drink water steadily through the day.",
    ];
    lifestyle = [
      "Exercise daily according to your capacity.",
      "Wake up earlier and avoid oversleeping.",
      "Stay active after meals.",
      "Track symptoms like thirst, urination, and energy over time.",
    ];
    yogaPoses = [
      "Surya Namaskar according to ability.",
      "Standing poses for activation.",
      "Twists for metabolic support.",
    ];
    avoid = [
      "Oversleeping",
      "Sedentary routine",
      "Repeated sugary foods",
      "Heavy late dinners",
    ];
  } else if (normalized.some((s) => ["acidity", "acid reflux", "burning", "rashes"].some((k) => s.includes(k)))) {
    predictedDisease = "Pitta digestive imbalance";
  } else if (normalized.some((s) => ["anxiety", "insomnia", "constipation", "dry skin"].some((k) => s.includes(k)))) {
    predictedDisease = "Vata nervous and digestive imbalance";
  } else if (normalized.some((s) => ["cough", "sinus", "weight gain", "low energy"].some((k) => s.includes(k)))) {
    predictedDisease = "Kapha metabolic and respiratory imbalance";
  }

  return {
    predictedDisease,
    doshaImbalance: dosha,
    confidence: "72%",
    description,
    remedies,
    foods,
    lifestyle,
    yogaPoses,
    avoid,
  };
}

function buildDoshaFallback(scores: Record<string, number>, primaryDosha: string) {
  const doshaName = primaryDosha.charAt(0).toUpperCase() + primaryDosha.slice(1);
  const descriptions: Record<string, string> = {
    Vata: "Vata types are often creative, quick-thinking, and energetic, but may become dry, irregular, or overstimulated when out of balance.",
    Pitta: "Pitta types are focused, sharp, and driven, but can become overheated, impatient, or inflamed when balance is lost.",
    Kapha: "Kapha types are steady, calm, and grounded, but may feel heavy, sluggish, or attached when imbalanced.",
  };

  const advice: Record<string, string[]> = {
    Vata: ["Keep a steady daily routine.", "Prefer warm cooked meals.", "Stay physically warm.", "Use calming breathwork.", "Reduce overstimulation at night.", "Eat meals on time.", "Favor grounding yoga.", "Rest when mentally overloaded."],
    Pitta: ["Choose cooling foods and routines.", "Avoid excessive heat and overwork.", "Use moderation with spicy foods.", "Practice calming pranayama.", "Schedule breaks during intense work.", "Spend time in nature.", "Favor non-competitive exercise.", "Support digestion without overheating."],
    Kapha: ["Stay active every day.", "Favor lighter meals.", "Avoid oversleeping.", "Use stimulating spices moderately.", "Keep routines energizing.", "Exercise in the morning.", "Reduce heavy dairy and fried foods.", "Prioritize motivation and movement."],
  };

  return {
    dosha: doshaName,
    description: descriptions[doshaName] || descriptions.Vata,
    scores,
    lifestyleAdvice: advice[doshaName] || advice.Vata,
    recommendations: [
      "Eat according to appetite rather than habit.",
      "Favor fresh meals over processed foods.",
      "Include seasonal foods that feel balancing.",
      "Hydrate consistently through the day.",
      "Reduce foods that aggravate your dominant dosha.",
      "Notice how digestion responds to different meals.",
      "Avoid irregular meal timing.",
      "Keep dinner lighter than lunch.",
    ],
    herbsAndSupplements: [
      "Ashwagandha: commonly used for resilience and balance.",
      "Triphala: often used for digestive support.",
      "Turmeric: traditional support for inflammation and metabolism.",
      "Tulsi: supports stress balance and respiratory wellness.",
      "Brahmi: often used for mental clarity and calm.",
      "Consult a practitioner before combining herbs routinely.",
    ],
    yogaPoses: ["Child's Pose", "Seated Twist", "Cat-Cow", "Mountain Pose", "Legs-Up-the-Wall"],
    dailyRoutine: ["Wake at a consistent time.", "Drink warm water in the morning.", "Eat meals on schedule.", "Take a short walk daily.", "Wind down before bed.", "Sleep at a regular hour."],
    avoid: ["Irregular routines", "Overeating", "Excess stress", "Skipping rest", "Foods that clearly aggravate symptoms"],
  };
}

function buildRemedyFallback(symptoms: string[]) {
  const normalized = symptoms.map((s) => s.toLowerCase());
  const hasAny = (keywords: string[]) => normalized.some((symptom) => keywords.some((keyword) => symptom.includes(keyword)));

  const isRespiratory = hasAny(["cold", "cough", "sore throat", "sinus", "bronch", "asthma", "chest"]);
  const isDigestive = hasAny(["constipation", "diarrhea", "bloating", "acid", "appetite", "indigestion", "nausea", "gas"]);
  const isStress = hasAny(["anxiety", "stress", "insomnia", "burnout", "depression", "brain fog"]);
  const isSkin = hasAny(["acne", "eczema", "psoriasis", "rashes", "itching", "dry skin", "hair"]);
  const isJoint = hasAny(["joint", "back pain", "arthritis", "muscle", "sciatica", "knee", "neck"]);
  const isMetabolic = hasAny(["diabetes", "obesity", "thyroid", "pcos", "cholesterol", "blood pressure", "anemia", "immunity", "fatigue", "hormonal"]);
  const isUrinary = hasAny(["uti", "kidney", "prostate", "menstrual", "infertility", "libido", "menopausal", "leucorrhea", "bed wetting"]);
  const isEyesOrOral = hasAny(["eye", "ear", "tinnitus", "tooth", "gum", "mouth ulcer", "bad breath", "vision", "night blindness", "dry eyes"]);

  let remedies = [
    "Ginger tea: simmer fresh ginger in water and sip warm after meals.",
    "Turmeric milk: use a small pinch of turmeric in warm milk or plant milk at night if tolerated.",
    "Cumin-coriander-fennel tea: boil lightly and sip through the day.",
    "Tulsi infusion: drink warm tulsi tea for general respiratory and stress support.",
    "Warm sesame oil self-massage: apply lightly before bath for grounding and circulation.",
    "Steam inhalation for congestion using plain hot water.",
    "Simple khichdi for a gentle digestive reset.",
    "Adequate hydration and regular meals to reduce aggravation.",
  ];

  let naturalTreatments = [
    "Gentle stretching or walking after meals.",
    "Prioritize sleep and regular meal timing.",
    "Use warm foods and avoid iced drinks.",
    "Reduce packaged, overly spicy, or fried food.",
    "Practice slow breathing for 5 to 10 minutes daily.",
    "Track which foods worsen symptoms and reduce them.",
  ];

  let healingFoods = [
    "Warm soups and stews for easier digestion.",
    "Rice and mung dal khichdi as a simple balancing meal.",
    "Cooked seasonal vegetables with mild spices.",
    "Herbal teas instead of sugary drinks.",
    "Stewed apples or pears if digestion feels weak.",
    "Light, fresh meals rather than heavy late dinners.",
  ];

  let herbalTeas = [
    "Ginger tea with a small amount of honey once lukewarm.",
    "Cumin-coriander-fennel tea after meals.",
    "Tulsi tea for calming support.",
    "Mint-fennel tea if excess heat is present.",
  ];

  let oilsAndMassage = [
    "Sesame oil for grounding massage if dryness is present.",
    "Coconut oil for a cooling effect if heat is present.",
    "Gentle circular abdominal massage for digestive comfort.",
  ];

  let yogaAndPranayama = [
    "Cat-Cow for spinal mobility and digestion.",
    "Child's Pose for relaxation.",
    "Alternate nostril breathing for nervous system balance.",
    "Short evening walk for circulation and digestion.",
  ];

  if (isRespiratory) {
    remedies = [
      "Tulsi-ginger tea: boil tulsi leaves with ginger and sip warm for throat and congestion support.",
      "Turmeric with warm water or milk: traditionally used for cough and throat irritation support.",
      "Steam inhalation: inhale plain steam carefully for sinus and nasal congestion.",
      "Honey with a pinch of black pepper: use only if suitable and not for very young children.",
      "Warm salt-water gargles for sore throat comfort.",
      "Ajwain steam or inhalation for blocked nasal passages.",
      "Mulethi tea in small amounts for throat soothing if suitable.",
      "Rest and warm fluids throughout the day.",
    ];
    naturalTreatments = [
      "Take complete rest and avoid cold exposure.",
      "Use steam inhalation 1 to 2 times daily.",
      "Keep the throat warm and avoid chilled drinks.",
      "Sleep with the head slightly elevated if congestion is heavy.",
      "Use gentle breathing only; avoid forceful pranayama during active cough.",
      "Seek medical care if breathing trouble or high fever appears.",
    ];
    healingFoods = [
      "Warm soups with black pepper and ginger.",
      "Light khichdi instead of heavy meals.",
      "Warm water with lemon if it feels suitable.",
      "Cooked vegetables rather than fried foods.",
      "Garlic in meals for warming support if tolerated.",
      "Avoid ice cream, cold drinks, and refrigerated food.",
    ];
    herbalTeas = [
      "Tulsi-ginger tea.",
      "Licorice root tea for throat soothing if appropriate.",
      "Pepper-tulsi infusion in small amounts.",
      "Cinnamon-ginger tea for warming support.",
    ];
    oilsAndMassage = [
      "Warm sesame oil on chest and upper back followed by gentle steam.",
      "Eucalyptus-based inhalation if already known to suit you.",
      "Warm foot massage before sleep to support rest.",
    ];
    yogaAndPranayama = [
      "Gentle chest-opening stretches.",
      "Supported Child's Pose for relaxation.",
      "Mild Anulom Vilom only when breathing feels clear enough.",
      "Short indoor walks to avoid sluggishness.",
    ];
  } else if (isDigestive) {
    remedies = [
      "Cumin-coriander-fennel tea: sip after meals for digestive comfort.",
      "Fresh ginger with a pinch of rock salt before meals if appetite feels low and heat is not excessive.",
      "Warm rice gruel or khichdi during digestive upset.",
      "Roasted fennel seeds after meals for bloating support.",
      "Isabgol with warm water at night if constipation is present and suitable for you.",
      "Pomegranate or ripe banana in moderation may help loose stools.",
      "Buttermilk with roasted cumin can support digestion if tolerated.",
      "Avoid overeating until digestion settles.",
    ];
    naturalTreatments = [
      "Eat at regular times and avoid skipping meals.",
      "Choose freshly cooked, simple foods for a few days.",
      "Avoid combining very heavy, oily, and spicy meals together.",
      "Take a slow walk for 10 minutes after meals.",
      "Avoid lying down immediately after eating.",
      "Seek medical care for dehydration, blood in stool, or severe pain.",
    ];
    healingFoods = [
      "Khichdi with cumin and a little ginger.",
      "Stewed apple for gentle digestive support.",
      "Plain rice, toast, or banana during loose motions if tolerated.",
      "Cooked bottle gourd or pumpkin for easier digestion.",
      "Warm water instead of carbonated or iced drinks.",
      "Homemade curd rice or buttermilk only if it suits your digestion.",
    ];
    herbalTeas = [
      "Fennel tea after meals.",
      "Cumin-coriander tea for bloating.",
      "Ginger tea for sluggish digestion.",
      "Mint tea for nausea if heat is not excessive.",
    ];
    oilsAndMassage = [
      "Gentle clockwise abdominal massage with warm sesame oil.",
      "Warm castor oil pack only if already advised and suitable.",
      "Light foot massage before bed to reduce digestive stress.",
    ];
    yogaAndPranayama = [
      "Vajrasana after meals for a few minutes.",
      "Seated Twist for digestive stimulation.",
      "Apanasana for gas relief.",
      "Slow diaphragmatic breathing to calm gut tension.",
    ];
  } else if (isStress) {
    remedies = [
      "Ashwagandha milk or tea if it suits your constitution and routine.",
      "Brahmi support may help calm and focus when used appropriately.",
      "Tulsi tea for stress support through the day.",
      "Warm milk with nutmeg at night if sleep is disturbed and milk suits you.",
      "Abhyanga with warm sesame oil before bath for nervous system grounding.",
      "Triphala at night only if digestion also needs support.",
      "A consistent bedtime routine is itself a strong remedy.",
      "Limit caffeine late in the day.",
    ];
    naturalTreatments = [
      "Keep a fixed sleep and wake time.",
      "Reduce screen exposure before bed.",
      "Practice 10 minutes of alternate nostril breathing daily.",
      "Take short breaks from overstimulating work.",
      "Use calming evening stretches instead of intense late exercise.",
      "Seek professional help if low mood becomes persistent or severe.",
    ];
    healingFoods = [
      "Warm cooked meals instead of dry snack-based eating.",
      "Soaked almonds if suitable for you.",
      "Oats, rice, and simple soups for steady nourishment.",
      "Herbal teas instead of repeated caffeine.",
      "Dates in moderation if energy feels depleted.",
      "Avoid late-night heavy meals and excess stimulants.",
    ];
    herbalTeas = [
      "Tulsi tea.",
      "Chamomile-style calming tea if used in your routine.",
      "Brahmi tea if available.",
      "Nutmeg milk at bedtime in small quantity if suitable.",
    ];
    oilsAndMassage = [
      "Warm sesame oil foot massage before sleep.",
      "Full-body abhyanga on stressful days.",
      "Gentle scalp oiling for relaxation.",
    ];
    yogaAndPranayama = [
      "Legs-Up-the-Wall for calming.",
      "Child's Pose and seated forward bend.",
      "Anulom Vilom for nervous system balance.",
      "Bhramari pranayama for stress reduction.",
    ];
  } else if (isSkin) {
    remedies = [
      "Neem support is traditionally used for some skin-related imbalances when appropriate.",
      "Turmeric in food can support inflammatory balance.",
      "Aloe vera application may soothe mild irritation if your skin tolerates it.",
      "Coriander and fennel water may help reduce internal heat for some people.",
      "Avoid scratching and use gentle skin care.",
      "Use simple, fragrance-free cleansing where possible.",
      "Support digestion, as skin flare-ups often worsen with dietary triggers.",
      "Consult a dermatologist for severe or persistent skin disease.",
    ];
    naturalTreatments = [
      "Avoid very spicy, greasy, and heavily processed foods.",
      "Hydrate well and keep sleep regular.",
      "Use breathable cotton clothing if irritation is present.",
      "Track foods that trigger flare-ups.",
      "Avoid harsh cosmetic products during flare periods.",
      "Seek medical care for infected, spreading, or severe lesions.",
    ];
    healingFoods = [
      "Cucumber and cooked gourds for lighter meals.",
      "Pomegranate and seasonal fruits that do not aggravate you.",
      "Leafy vegetables in cooked form.",
      "Coriander and fennel in meals.",
      "Reduce refined sugar and deep-fried foods.",
      "Favor simple meals that support digestion.",
    ];
    herbalTeas = [
      "Coriander seed tea.",
      "Fennel tea for cooling digestive support.",
      "Neem-based infusions only if already known to suit you.",
      "Aloe or amla support under proper guidance.",
    ];
    oilsAndMassage = [
      "Coconut oil for cooling external application if suitable.",
      "Avoid heavy oil massage over actively inflamed skin.",
      "Use gentle scalp oiling if hair dryness is present.",
    ];
    yogaAndPranayama = [
      "Cooling breath practices if appropriate.",
      "Gentle twists and walks to support digestion.",
      "Restorative yoga to reduce stress-driven flare-ups.",
      "Meditation for stress-related skin worsening.",
    ];
  } else if (isJoint) {
    remedies = [
      "Dry ginger and turmeric in food for warming support if suitable.",
      "Warm castor oil or sesame oil local massage for stiffness.",
      "Epsom salt or warm water soak for non-inflamed soreness.",
      "Dashmool-based support may be used traditionally under guidance.",
      "Gentle heat application for tight muscles if it feels relieving.",
      "Avoid sudden strain and overuse during pain flares.",
      "Support digestion because ama is often linked with stiffness in Ayurveda.",
      "Seek medical care for swelling, injury, numbness, or severe pain.",
    ];
    naturalTreatments = [
      "Do gentle mobility work every day instead of long inactivity.",
      "Use heat for stiffness and rest when pain spikes.",
      "Avoid sleeping in positions that strain the painful area.",
      "Take short walking breaks instead of prolonged sitting.",
      "Work on posture and ergonomic support.",
      "Get evaluated if pain is persistent or progressive.",
    ];
    healingFoods = [
      "Warm soups and anti-inflammatory home-cooked meals.",
      "Use turmeric, ginger, cumin, and garlic if suitable.",
      "Avoid very cold foods if stiffness worsens with cold.",
      "Reduce excess sugar and processed snacks.",
      "Stay hydrated for joint comfort.",
      "Favor lighter dinners to reduce heaviness.",
    ];
    herbalTeas = [
      "Ginger tea for warming support.",
      "Turmeric tea in small amounts.",
      "Coriander-fennel tea if digestion also needs support.",
      "Tulsi tea for general wellness support.",
    ];
    oilsAndMassage = [
      "Warm sesame oil massage over stiff joints.",
      "Mahanarayan-style oil only if already part of your routine.",
      "Warm compress after oil application for stiffness.",
    ];
    yogaAndPranayama = [
      "Cat-Cow for spine and joint mobility.",
      "Gentle hamstring and hip stretches.",
      "Supported bridge or restorative poses.",
      "Slow breathing to reduce pain-related tension.",
    ];
  } else if (isMetabolic) {
    remedies = [
      "Fenugreek seeds soaked overnight may support metabolic balance for some people.",
      "Cinnamon in small culinary amounts can support balanced glucose response.",
      "Triphala may support digestion and bowel regularity when suitable.",
      "Amla is traditionally used for vitality and antioxidant support.",
      "Guduchi may be used in Ayurvedic wellness routines under guidance.",
      "Warm water through the day can support digestion and heaviness.",
      "Use spices like cumin, coriander, and turmeric in regular meals.",
      "Work with a clinician for diabetes, thyroid, anemia, or blood pressure management.",
    ];
    naturalTreatments = [
      "Walk daily after meals to support metabolism.",
      "Keep meal timing regular and avoid frequent overeating.",
      "Prioritize morning movement and consistent sleep.",
      "Reduce refined sugar and ultra-processed snacks.",
      "Track weight, energy, and appetite patterns over time.",
      "Follow medical monitoring for blood sugar, thyroid, or blood pressure conditions.",
    ];
    healingFoods = [
      "High-fiber cooked vegetables with balanced protein.",
      "Whole grains in moderate portions instead of refined flour foods.",
      "Mung dal and lighter lentil-based meals.",
      "Amla, bitter gourd, or methi in suitable meals when appropriate.",
      "Iron-supportive foods for low energy or anemia under dietary guidance.",
      "Avoid very heavy late dinners and repeated sugary drinks.",
    ];
    herbalTeas = [
      "Cinnamon-fenugreek tea in small amounts.",
      "Coriander-cumin-fennel tea for digestive support.",
      "Amla-based wellness drink if already tolerated.",
      "Tulsi tea for stress and metabolic routine support.",
    ];
    oilsAndMassage = [
      "Dry powder massage or brisk self-massage for heaviness if suitable.",
      "Sesame oil massage for fatigue and circulation support.",
      "Avoid very heavy oiling if it increases lethargy.",
    ];
    yogaAndPranayama = [
      "Brisk walking or Surya Namaskar according to ability.",
      "Twists and standing poses for metabolic activation.",
      "Kapalabhati only if appropriate and medically suitable.",
      "Anulom Vilom for stress-related hormonal balance.",
    ];
  } else if (isUrinary) {
    remedies = [
      "Coriander seed water is traditionally used for mild urinary heat support.",
      "Barley water may help support hydration and urinary comfort.",
      "Coconut water in moderation may feel soothing in some cases of heat.",
      "Warm compress for lower abdominal discomfort if it feels relieving.",
      "Sesame oil lower-abdominal massage may support cramp relief around menstruation.",
      "Hydration is essential for urinary discomfort unless medically restricted.",
      "Use gentle digestive foods while the body feels irritated.",
      "Seek medical care promptly for UTI symptoms, kidney pain, or reproductive concerns.",
    ];
    naturalTreatments = [
      "Increase water intake unless your doctor advised fluid restriction.",
      "Do not hold urine for long periods.",
      "Maintain genital hygiene and breathable clothing.",
      "Use warmth and rest during menstrual cramps.",
      "Avoid irritants such as very spicy food if urinary burning is present.",
      "See a doctor for fever, flank pain, blood in urine, or recurrent infection.",
    ];
    healingFoods = [
      "Light soups and warm simple meals during urinary discomfort.",
      "Barley or rice-based light meals.",
      "Cucumber or bottle gourd if cooling foods suit you.",
      "Pomegranate and cooked fruits in moderation.",
      "Avoid excessive caffeine and very spicy foods.",
      "Use easy-to-digest foods during menstrual or urinary discomfort.",
    ];
    herbalTeas = [
      "Coriander seed tea.",
      "Cumin-coriander tea for gentle cooling support.",
      "Fennel tea if bloating and cramps are present.",
      "Tulsi tea for general stress support around symptoms.",
    ];
    oilsAndMassage = [
      "Warm castor or sesame oil lower-abdominal massage for cramps if suitable.",
      "Gentle foot massage for stress and sleep support.",
      "Avoid strong massage over acute pain or suspected infection.",
    ];
    yogaAndPranayama = [
      "Supta Baddha Konasana for pelvic relaxation.",
      "Child's Pose and gentle hip openers.",
      "Deep breathing for cramp-related tension.",
      "Short walks to reduce stiffness and heaviness.",
    ];
  } else if (isEyesOrOral) {
    remedies = [
      "Rose water eye compresses only if sterile and already known to suit you.",
      "Triphala eyewash should only be used with proper guidance and sterile preparation.",
      "Warm salt-water gargles for gum or throat comfort.",
      "Clove in tiny culinary amounts may support temporary tooth discomfort, but it is not a dental substitute.",
      "Steam inhalation may help some ear or sinus-related pressure issues.",
      "Use simple, non-irritating oral hygiene while ulcers or gum irritation are active.",
      "Rest the eyes and reduce screen strain frequently.",
      "See an eye doctor or dentist for persistent pain, infection, or vision changes.",
    ];
    naturalTreatments = [
      "Follow the 20-20-20 rule for screen strain.",
      "Keep hydration adequate for dry eyes and dry mouth.",
      "Avoid rubbing irritated eyes.",
      "Use gentle oral hygiene and avoid very spicy foods during mouth ulcers.",
      "Do not self-treat serious eye pain, ear discharge, or dental swelling.",
      "Get professional care for persistent tinnitus, infection, or vision loss.",
    ];
    healingFoods = [
      "Hydrating foods like soups and cooked vegetables.",
      "Amla and colorful vegetables for general eye-supportive nutrition.",
      "Soft, non-spicy foods during mouth ulcers.",
      "Warm foods over very dry, crunchy irritants when oral pain is present.",
      "Reduce sugary foods for gum and oral health.",
      "Use balanced meals that support hydration and micronutrients.",
    ];
    herbalTeas = [
      "Fennel tea for cooling support.",
      "Coriander tea for heat-related irritation support.",
      "Tulsi tea for general immune support.",
      "Chamomile-style tea if already part of your routine and suitable.",
    ];
    oilsAndMassage = [
      "Gentle temple massage for eye strain-related tension.",
      "Foot massage may support relaxation and screen-stress relief.",
      "Do not put oils into the eyes or ears unless medically instructed.",
    ];
    yogaAndPranayama = [
      "Palming and blinking exercises for screen fatigue.",
      "Neck stretches for posture-related eye strain.",
      "Bhramari for tension relief.",
      "Gentle meditation to reduce stress-linked jaw or eye tension.",
    ];
  }

  return {
    condition: symptoms.join(", "),
    remedies,
    naturalTreatments,
    healingFoods,
    herbalTeas,
    oilsAndMassage,
    yogaAndPranayama,
    warnings: [
      "Do not rely on home remedies alone for severe or worsening symptoms.",
      "Seek medical care for chest pain, breathing trouble, or persistent fever.",
      "Check herb interactions if you use prescription medicines.",
      "Stop any remedy that clearly worsens symptoms.",
    ],
  };
}

function uniqueStrings(items: unknown[]) {
  const seen = new Set<string>();
  const result: string[] = [];

  for (const item of items) {
    if (typeof item !== "string") continue;
    const value = item.trim();
    const key = value.toLowerCase();
    if (!value || seen.has(key)) continue;
    seen.add(key);
    result.push(value);
  }

  return result;
}

function normalizeRemedyResult(result: any, symptoms: string[]) {
  const fallback = buildRemedyFallback(symptoms);
  const remedies = uniqueStrings(Array.isArray(result?.remedies) ? result.remedies : []);
  let naturalTreatments = uniqueStrings(Array.isArray(result?.naturalTreatments) ? result.naturalTreatments : []);

  const remedyKeys = new Set(remedies.map((item) => item.toLowerCase()));
  naturalTreatments = naturalTreatments.filter((item) => !remedyKeys.has(item.toLowerCase()));

  if (naturalTreatments.length === 0) {
    naturalTreatments = fallback.naturalTreatments;
  }

  return {
    condition: typeof result?.condition === "string" && result.condition.trim() ? result.condition : fallback.condition,
    remedies: remedies.length > 0 ? remedies : fallback.remedies,
    naturalTreatments,
    healingFoods: uniqueStrings(Array.isArray(result?.healingFoods) ? result.healingFoods : []).slice(0, 6).length > 0
      ? uniqueStrings(Array.isArray(result?.healingFoods) ? result.healingFoods : []).slice(0, 6)
      : fallback.healingFoods,
    herbalTeas: uniqueStrings(Array.isArray(result?.herbalTeas) ? result.herbalTeas : []).slice(0, 4).length > 0
      ? uniqueStrings(Array.isArray(result?.herbalTeas) ? result.herbalTeas : []).slice(0, 4)
      : fallback.herbalTeas,
    oilsAndMassage: uniqueStrings(Array.isArray(result?.oilsAndMassage) ? result.oilsAndMassage : []).slice(0, 3).length > 0
      ? uniqueStrings(Array.isArray(result?.oilsAndMassage) ? result.oilsAndMassage : []).slice(0, 3)
      : fallback.oilsAndMassage,
    yogaAndPranayama: uniqueStrings(Array.isArray(result?.yogaAndPranayama) ? result.yogaAndPranayama : []).slice(0, 4).length > 0
      ? uniqueStrings(Array.isArray(result?.yogaAndPranayama) ? result.yogaAndPranayama : []).slice(0, 4)
      : fallback.yogaAndPranayama,
    warnings: uniqueStrings(Array.isArray(result?.warnings) ? result.warnings : []).slice(0, 4).length > 0
      ? uniqueStrings(Array.isArray(result?.warnings) ? result.warnings : []).slice(0, 4)
      : fallback.warnings,
  };
}

async function callGroqAI(systemPrompt: string, userMessage: string) {
  return await groqService.chatJSON(systemPrompt, userMessage, {
    temperature: 0.5,
    maxTokens: 1000,
  });
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // SYSTEM & AI HEALTH ENDPOINTS
  app.get("/api/health", async (_req, res) => {
    res.status(200).json({
      status: "healthy",
      service: "AmritVeda AI Platform",
      timestamp: new Date().toISOString(),
      groq: groqService.getHealth(),
      mlModel: mlModelService.getHealth(),
    });
  });

  app.get("/api/groq/health", async (_req, res) => {
    res.status(200).json(groqService.getHealth());
  });

  app.get("/api/ml/health", async (_req, res) => {
    res.status(200).json(mlModelService.getHealth());
  });

  // Backward compatibility alias
  app.get("/api/ai/health", async (_req, res) => {
    res.status(200).json(groqService.getHealth());
  });

  // AUTH
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existingUser = await storage.getUserByEmail(input.email);
      if (existingUser) return res.status(400).json({ message: "User already exists with this email" });
      const hashedPassword = await bcrypt.hash(input.password, 10);
      const user = await storage.createUser({ ...input, password: hashedPassword });
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.auth.login.path, async (req, res) => {
    try {
      const input = api.auth.login.input.parse(req.body);
      const user = await storage.getUserByEmail(input.email);
      if (!user) return res.status(401).json({ message: "Invalid email or password" });
      const validPassword = await bcrypt.compare(input.password, user.password);
      if (!validPassword) return res.status(401).json({ message: "Invalid email or password" });
      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "24h" });
      res.status(200).json({ user, token });
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.auth.profile.path, authenticateToken, async (req, res) => {
    const userId = (req as any).user.id;
    const user = await storage.getUser(userId);
    if (!user) return res.status(401).json({ message: "User not found" });
    res.status(200).json(user);
  });

  // DISEASE PREDICTION with AI ORCHESTRATION (Trained ML Model + Groq AI)
  app.post(api.disease.predict.path, authenticateToken, async (req, res) => {
    let input: z.infer<typeof api.disease.predict.input> | undefined;
    try {
      input = api.disease.predict.input.parse(req.body);
      const result = await aiOrchestrator.assessDisease(input.symptoms, buildDiseaseFallback);
      const userId = (req as any).user.id;
      await storage.createPrediction({
        userId,
        symptoms: input.symptoms,
        predictedDisease: result.predictedDisease,
        confidence: result.confidence,
        remedies: result.remedies || [],
        foods: result.foods || [],
      });
      res.status(200).json(result);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Disease prediction error:", err);
      if (input) {
        const fallback = buildDiseaseFallback(input.symptoms);
        const userId = (req as any).user.id;
        await storage.createPrediction({
          userId,
          symptoms: input.symptoms,
          predictedDisease: fallback.predictedDisease,
          confidence: fallback.confidence,
          remedies: fallback.remedies,
          foods: fallback.foods,
        });
        return res.status(200).json({
          ...fallback,
          isFromTrainedML: false,
          modelInfo: { status: mlModelService.getHealth().statusMessage },
          disclaimer: "⚕️ AmritVeda Medical Disclaimer: This assessment is generated for wellness guidance only. Consult a doctor for medical diagnosis.",
        });
      }
      const aiError = getAIErrorResponse(err);
      res.status(aiError.status).json({ message: aiError.message });
    }
  });

  // DOSHA ANALYSIS with GROQ AI
  app.post(api.dosha.analyze.path, authenticateToken, async (req, res) => {
    try {
      const input = api.dosha.analyze.input.parse(req.body);
      const answers = input.answers;

      // Local scoring
      const scores: Record<string, number> = { vata: 0, pitta: 0, kapha: 0 };
      const doshaMap: Record<string, string> = {
        thin: "vata", dry: "vata", anxious: "vata", variable: "vata", light: "vata",
        cold: "vata", creative: "vata", fast: "vata", irregular: "vata", flexible: "vata",
        medium: "pitta", sensitive: "pitta", angry: "pitta", focused: "pitta", moderate: "pitta",
        warm: "pitta", sharp: "pitta", competitive: "pitta", oily_pitta: "pitta",
        large: "kapha", oily: "kapha", withdrawn: "kapha", steady: "kapha", deep: "kapha",
        moist: "kapha", methodical: "kapha", slow: "kapha", heavy: "kapha",
      };

      for (const val of Object.values(answers)) {
        const dosha = doshaMap[val as string];
        if (dosha) scores[dosha]++;
      }

      const primaryDosha = Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
      const fallbackResult = buildDoshaFallback(scores, primaryDosha);

      let aiResult: any = null;
      if (groqService.isConfigured()) {
        try {
          const systemPrompt = `You are a master Ayurvedic practitioner. Based on the dosha constitution analysis, provide personalized comprehensive wellness advice.
          
          Respond ONLY in valid JSON with this structure:
          {
            "dosha": "dominant dosha name (capitalize first letter)",
            "description": "3-4 sentence description of this dosha personality and physical traits",
            "scores": { "vata": number, "pitta": number, "kapha": number },
            "lifestyleAdvice": ["detailed lifestyle tip", ...8 items],
            "recommendations": ["dietary recommendation with specifics", ...8 items],
            "herbsAndSupplements": ["herb name: how to use and benefit", ...6 items],
            "yogaPoses": ["pose name: benefit for this dosha", ...5 items],
            "dailyRoutine": ["morning/evening routine item", ...6 items],
            "avoid": ["foods/activities to avoid", ...5 items]
          }`;

          aiResult = await callGroqAI(
            systemPrompt,
            `Patient's dosha scores: Vata=${scores.vata}, Pitta=${scores.pitta}, Kapha=${scores.kapha}. Primary dosha: ${primaryDosha}. Quiz answers: ${JSON.stringify(answers)}`
          );
        } catch (err: any) {
          console.warn("[Dosha Analysis] Groq error, falling back:", err.message);
        }
      }

      if (!aiResult) {
        aiResult = fallbackResult;
      }

      aiResult.dosha = fallbackResult.dosha;
      aiResult.scores = scores;

      const userId = (req as any).user.id;
      await storage.updateUser(userId, { dosha: aiResult.dosha });

      res.status(200).json(aiResult);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Dosha analysis error:", err);
      const answers = api.dosha.analyze.input.parse(req.body).answers;
      const scores: Record<string, number> = { vata: 0, pitta: 0, kapha: 0 };
      const doshaMap: Record<string, string> = {
        thin: "vata", dry: "vata", anxious: "vata", variable: "vata", light: "vata",
        cold: "vata", creative: "vata", fast: "vata", irregular: "vata", flexible: "vata",
        medium: "pitta", sensitive: "pitta", angry: "pitta", focused: "pitta", moderate: "pitta",
        warm: "pitta", sharp: "pitta", competitive: "pitta", oily_pitta: "pitta",
        large: "kapha", oily: "kapha", withdrawn: "kapha", steady: "kapha", deep: "kapha",
        moist: "kapha", methodical: "kapha", slow: "kapha", heavy: "kapha",
      };
      for (const val of Object.values(answers)) {
        const dosha = doshaMap[val as string];
        if (dosha) scores[dosha]++;
      }
      const primaryDosha = Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
      const fallback = buildDoshaFallback(scores, primaryDosha);
      const userId = (req as any).user.id;
      await storage.updateUser(userId, { dosha: fallback.dosha });
      res.status(200).json(fallback);
    }
  });

  // REMEDY GENERATOR with AI ORCHESTRATION
  app.post(api.remedy.generate.path, authenticateToken, async (req, res) => {
    let input: z.infer<typeof api.remedy.generate.input> | undefined;
    try {
      input = api.remedy.generate.input.parse(req.body);
      const result = await aiOrchestrator.generateRemedies(input.symptoms, (syms) =>
        normalizeRemedyResult(buildRemedyFallback(syms), syms)
      );
      res.status(200).json(result);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Remedy generation error:", err);
      if (input) {
        return res.status(200).json(buildRemedyFallback(input.symptoms));
      }
      const aiError = getAIErrorResponse(err);
      res.status(aiError.status).json({ message: aiError.message });
    }
  });

  // CHAT with GROQ AI (Veda Assistant) - Context-Aware with Stored User Profile & Dosha Quiz
  app.post(api.chat.send.path, authenticateToken, async (req, res) => {
    try {
      const input = api.chat.send.input.parse(req.body);
      const userId = (req as any).user?.id;

      let userProfile = undefined;
      let userPredictions: any[] = [];
      if (typeof userId === "number") {
        userProfile = await storage.getUser(userId);
        try {
          userPredictions = await storage.getPredictions(userId);
        } catch {
          userPredictions = [];
        }
      }

      const latestAssessment =
        userPredictions.length > 0
          ? userPredictions[userPredictions.length - 1]
          : undefined;

      const userContext = {
        userId,
        name: userProfile?.name,
        dosha: userProfile?.dosha,
        bloodGroup: userProfile?.bloodGroup,
        latestAssessment: latestAssessment
          ? {
              disease: latestAssessment.predictedDisease,
              confidence: latestAssessment.confidence,
              symptoms: Array.isArray(latestAssessment.symptoms)
                ? (latestAssessment.symptoms as string[])
                : [],
            }
          : undefined,
      };

      const history = (input.history || []).map((h) => ({
        role: (h.role === "bot" ? "assistant" : "user") as "user" | "assistant",
        content: h.content,
      }));

      const response = await aiOrchestrator.chatWithVeda(
        input.message,
        history,
        userContext
      );
      res.status(200).json({ response });
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Chat error:", err);
      const aiError = getAIErrorResponse(err);
      res.status(aiError.status).json({ message: aiError.message });
    }
  });

  // PRACTITIONER PATIENTS
  app.get(api.practitioner.patients.path, authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "practitioner") return res.status(401).json({ message: "Unauthorized" });
      const patients = await storage.getPractitionerPatients(user.id);
      res.status(200).json(patients);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/practitioner/patients/:patientId", authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "practitioner") return res.status(401).json({ message: "Unauthorized" });

      const patientId = Number(req.params.patientId);
      const review = await storage.getPatientReview(patientId);
      if (!review.patient || review.patient.role !== "patient") {
        return res.status(404).json({ message: "Patient not found" });
      }

      res.status(200).json(review);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.practitioner.createTreatment.path, authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "practitioner") return res.status(401).json({ message: "Unauthorized" });

      const input = api.practitioner.createTreatment.input.parse(req.body);
      const treatment = await storage.createTreatment({
        practitionerId: user.id,
        patientId: input.patientId,
        notes: input.notes,
      });

      res.status(201).json(treatment);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.patient.treatments.path, authenticateToken, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "patient") return res.status(401).json({ message: "Unauthorized" });

      const treatments = await storage.getPatientVisibleTreatments(user.id);
      res.status(200).json(treatments);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  seedDatabase().catch(console.error);
  return httpServer;
}

async function seedDatabase() {
  try {
    const existing = await storage.getUserByEmail("practitioner@amritveda.com");
    if (!existing) {
      const hashedPassword = await bcrypt.hash("password123", 10);
      await storage.createUser({
        name: "Dr. Priya Sharma",
        email: "practitioner@amritveda.com",
        password: hashedPassword,
        role: "practitioner",
        contactNumber: "+91-9876543210",
        bloodGroup: "O+",
        dob: "1980-03-15",
      });
      const patient = await storage.createUser({
        name: "Rahul Kumar",
        email: "patient@example.com",
        password: hashedPassword,
        role: "patient",
        contactNumber: "+91-9123456789",
        bloodGroup: "B+",
        dob: "1995-05-15",
      });
      await storage.updateUser(patient.id, { dosha: "Vata" });
    }
  } catch (err) {
    console.error("Seed error:", err);
  }
}
