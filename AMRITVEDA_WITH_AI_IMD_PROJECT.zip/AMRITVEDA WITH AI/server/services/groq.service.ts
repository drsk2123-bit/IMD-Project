/**
 * AmritVeda Groq AI Service Module
 * Connects directly to Groq's official API (https://api.groq.com/openai/v1)
 *
 * Configured via:
 * - GROQ_API_KEY: The Groq Cloud API authentication key (from https://console.groq.com)
 * - GROQ_MODEL: Configurable model (defaults to llama-3.3-70b-versatile)
 * - GROQ_BASE_URL: Base API endpoint (defaults to https://api.groq.com/openai/v1)
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface GroqCompletionOptions {
  responseFormat?: "json_object" | "text";
  temperature?: number;
  maxTokens?: number;
  timeoutMs?: number;
}

export interface GroqHealthStatus {
  configured: boolean;
  provider: "Groq";
  model: string;
  endpoint: string;
  message: string;
}

export class GroqService {
  private get apiKey(): string | undefined {
    return process.env.GROQ_API_KEY;
  }

  private get baseURL(): string {
    return (process.env.GROQ_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/+$/, "");
  }

  private get model(): string {
    return process.env.GROQ_MODEL || "qwen/qwen3.8-27b";
  }

  public isConfigured(): boolean {
    const key = this.apiKey;
    return typeof key === "string" && key.trim().length > 0;
  }

  public getHealth(): GroqHealthStatus {
    const configured = this.isConfigured();
    return {
      configured,
      provider: "Groq",
      model: this.model,
      endpoint: `${this.baseURL}/chat/completions`,
      message: configured
        ? `Groq AI configured with model ${this.model}`
        : "GROQ_API_KEY is not set in environment. Add GROQ_API_KEY to your .env file.",
    };
  }

  /**
   * Send a chat completion request to the official Groq API with retries and timeout
   */
  public async chatCompletion(
    messages: ChatMessage[],
    options: GroqCompletionOptions = {}
  ): Promise<string> {
    const apiKey = this.apiKey;
    if (!apiKey) {
      throw new Error(
        "Groq API key is missing. Please set GROQ_API_KEY in your environment (.env file)."
      );
    }

    const {
      responseFormat = "text",
      temperature = 0.6,
      maxTokens = 1200,
      timeoutMs = 30000,
    } = options;

    const requestBody: Record<string, any> = {
      model: this.model,
      messages,
      temperature,
      max_tokens: maxTokens,
    };

    if (responseFormat === "json_object") {
      requestBody.response_format = { type: "json_object" };
    }

    const url = `${this.baseURL}/chat/completions`;
    const maxRetries = 3;
    let attempt = 0;
    let lastError: Error | null = null;

    while (attempt <= maxRetries) {
      attempt++;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey.trim()}`,
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal,
        });

        clearTimeout(timer);

        if (!response.ok) {
          const errorBody = await response.text();
          let parsedError: any;
          try {
            parsedError = JSON.parse(errorBody);
          } catch {
            parsedError = null;
          }

          const errMsg =
            parsedError?.error?.message ||
            parsedError?.message ||
            `HTTP ${response.status}: ${response.statusText}`;

          if (response.status === 401) {
            throw new Error(`Groq Authentication Failed: Invalid or expired GROQ_API_KEY. (${errMsg})`);
          } else if (response.status === 429) {
            if (attempt <= maxRetries) {
              const retryAfterHeader = response.headers.get("retry-after");
              const delay = retryAfterHeader ? Math.min(Number(retryAfterHeader) * 1000, 8000) : 2500 * attempt;
              await new Promise((resolve) => setTimeout(resolve, delay));
              continue;
            }
            throw new Error(`Groq Rate Limit Exceeded: ${errMsg}`);
          } else if (response.status === 404) {
            throw new Error(`Groq Model Not Found: The model '${this.model}' was not found. (${errMsg})`);
          } else if (response.status >= 500 && attempt <= maxRetries) {
            await new Promise((resolve) => setTimeout(resolve, 1000 * attempt));
            continue;
          }

          throw new Error(`Groq API Error (${response.status}): ${errMsg}`);
        }

        const data = await response.json();
        let content = data?.choices?.[0]?.message?.content;
        if ((!content || typeof content !== "string" || content.trim().length === 0) && data?.choices?.[0]?.message?.reasoning) {
          content = data.choices[0].message.reasoning;
        }

        if (typeof content !== "string") {
          throw new Error("Invalid response format received from Groq API.");
        }

        return content;
      } catch (err: any) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
          lastError = new Error(`Groq API request timed out after ${timeoutMs}ms.`);
        } else {
          lastError = err;
        }

        if (attempt <= maxRetries && !err.message?.includes("Invalid or expired")) {
          await new Promise((resolve) => setTimeout(resolve, 1000 * attempt));
          continue;
        }

        break;
      }
    }

    throw lastError || new Error("Failed to communicate with Groq API.");
  }

  /**
   * Helper to request structured JSON responses from Groq
   */
  public async chatJSON<T = any>(
    systemPrompt: string,
    userMessage: string,
    options: Omit<GroqCompletionOptions, "responseFormat"> = {}
  ): Promise<T> {
    const maxTokens = Math.max(options.maxTokens || 1500, 2000);

    try {
      const rawContent = await this.chatCompletion(
        [
          { role: "system", content: `${systemPrompt}\nOutput MUST be valid JSON.` },
          { role: "user", content: userMessage },
        ],
        {
          ...options,
          maxTokens,
          responseFormat: "json_object",
        }
      );

      const jsonText = sanitizeAndExtractJSON(rawContent);
      return JSON.parse(jsonText) as T;
    } catch (err: any) {
      // If json_object constrained mode fails or triggers 400 from model, fallback to standard prompt extraction
      if (
        err.message?.includes("Failed to generate JSON") ||
        err.message?.includes("json_object") ||
        err.message?.includes("400")
      ) {
        const rawFallback = await this.chatCompletion(
          [
            {
              role: "system",
              content: `${systemPrompt}\nIMPORTANT: Respond ONLY with a valid, clean JSON object starting with { and ending with }. No conversation, no markdown backticks.`,
            },
            { role: "user", content: userMessage },
          ],
          {
            ...options,
            maxTokens: 2500,
            responseFormat: "text",
          }
        );
        const extracted = sanitizeAndExtractJSON(rawFallback);
        return JSON.parse(extracted) as T;
      }
      console.error("[GroqService] JSON parse or fetch error:", err.message);
      throw err;
    }
  }
}

/**
 * Extracts and sanitizes JSON string from AI responses safely
 */
export function sanitizeAndExtractJSON(text: string): string {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");

  if (start === -1 || end === -1 || end <= start) {
    throw new Error("AI response did not contain a valid JSON object.");
  }

  const jsonSnippet = text.slice(start, end + 1);

  let result = "";
  let inString = false;
  let escaping = false;

  for (const char of jsonSnippet) {
    if (escaping) {
      result += char;
      escaping = false;
      continue;
    }

    if (char === "\\") {
      result += char;
      escaping = true;
      continue;
    }

    if (char === '"') {
      result += char;
      inString = !inString;
      continue;
    }

    if (inString && (char === "\n" || char === "\r" || char === "\t")) {
      result += " ";
      continue;
    }

    result += char;
  }

  return result;
}

export const groqService = new GroqService();

