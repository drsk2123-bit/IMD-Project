import fs from "fs";
import path from "path";
import { spawn } from "child_process";

/**
 * Interface representing the genuine prediction result from the trained ML model.
 */
export interface MLPredictionResult {
  isGenuineML: true;
  predictedDisease: string;
  confidence: number; // 0.0 to 1.0 (or percentage)
  confidenceFormatted: string; // e.g. "87.4%"
  probabilities?: Record<string, number>;
  rawOutput?: any;
  modelType: string;
  timestamp: string;
}

export interface MLModelHealth {
  enabled: boolean;
  isLoaded: boolean;
  modelPath: string | null;
  metadataPath: string | null;
  detectedFramework: string | null;
  featuresCount: number;
  classesCount: number;
  status: "READY" | "DISABLED" | "ARTIFACT_MISSING" | "LOAD_ERROR";
  statusMessage: string;
}

export interface PreprocessingMetadata {
  features?: string[];
  classes?: string[];
  framework?: string;
  version?: string;
  description?: string;
}

export class MLModelService {
  private isModelLoaded = false;
  private modelPath: string | null = null;
  private metadataPath: string | null = null;
  private metadata: PreprocessingMetadata = {};
  private detectedFramework: string | null = null;
  private loadError: string | null = null;

  constructor() {
    this.init();
  }

  /**
   * Initialize and inspect model configuration from environment
   */
  public init() {
    const isEnabled = process.env.MODEL_ENABLED !== "false";
    this.modelPath = process.env.MODEL_PATH || null;
    this.metadataPath = process.env.MODEL_METADATA_PATH || null;

    if (!isEnabled) {
      this.isModelLoaded = false;
      this.statusMessage = "ML Model is disabled via MODEL_ENABLED=false.";
      return;
    }

    // Check if model path is set
    if (!this.modelPath) {
      // Check standard locations for model files
      const candidatePaths = [
        path.resolve(process.cwd(), "ml-model", "disease_model.pkl"),
        path.resolve(process.cwd(), "ml-model", "model.joblib"),
        path.resolve(process.cwd(), "ml-model", "model.onnx"),
        path.resolve(process.cwd(), "ml-model", "model.pt"),
        path.resolve(process.cwd(), "models", "disease_model.pkl"),
        path.resolve(process.cwd(), "models", "model.onnx"),
      ];

      for (const p of candidatePaths) {
        if (fs.existsSync(p)) {
          this.modelPath = p;
          break;
        }
      }
    }

    if (!this.modelPath || !fs.existsSync(this.modelPath)) {
      this.isModelLoaded = false;
      this.loadError = this.modelPath
        ? `Configured model file does not exist at '${this.modelPath}'.`
        : "No model artifact file found in workspace. Provide trained model files (.pkl, .joblib, .pt, .onnx, .h5).";
      return;
    }

    // Inspect framework by extension
    const ext = path.extname(this.modelPath).toLowerCase();
    switch (ext) {
      case ".pkl":
      case ".pickle":
        this.detectedFramework = "Scikit-Learn / Pickle";
        break;
      case ".joblib":
        this.detectedFramework = "Scikit-Learn / Joblib";
        break;
      case ".onnx":
        this.detectedFramework = "ONNX Runtime";
        break;
      case ".pt":
      case ".pth":
        this.detectedFramework = "PyTorch";
        break;
      case ".h5":
      case ".keras":
        this.detectedFramework = "TensorFlow / Keras";
        break;
      default:
        this.detectedFramework = "Custom Binary";
    }

    // Check metadata
    if (!this.metadataPath) {
      const defaultMeta = path.join(path.dirname(this.modelPath), "metadata.json");
      if (fs.existsSync(defaultMeta)) {
        this.metadataPath = defaultMeta;
      }
    }

    if (this.metadataPath && fs.existsSync(this.metadataPath)) {
      try {
        const raw = fs.readFileSync(this.metadataPath, "utf-8");
        this.metadata = JSON.parse(raw);
      } catch (err: any) {
        console.warn("[MLModelService] Failed to parse metadata JSON:", err.message);
      }
    }

    this.isModelLoaded = true;
    this.loadError = null;
  }

  private statusMessage = "";

  public isAvailable(): boolean {
    return this.isModelLoaded;
  }

  public getHealth(): MLModelHealth {
    const isEnabled = process.env.MODEL_ENABLED !== "false";
    let status: MLModelHealth["status"] = "READY";
    let message = `Model loaded successfully (${this.detectedFramework}).`;

    if (!isEnabled) {
      status = "DISABLED";
      message = "ML model is disabled via configuration.";
    } else if (!this.isModelLoaded) {
      status = "ARTIFACT_MISSING";
      message =
        this.loadError ||
        "Trained model artifacts (.pkl, .pt, .onnx, .joblib, .h5) have not yet been placed in the repository.";
    }

    return {
      enabled: isEnabled,
      isLoaded: this.isModelLoaded,
      modelPath: this.modelPath,
      metadataPath: this.metadataPath,
      detectedFramework: this.detectedFramework,
      featuresCount: this.metadata.features?.length || 0,
      classesCount: this.metadata.classes?.length || 0,
      status,
      statusMessage: message,
    };
  }

  /**
   * Preprocess symptoms according to model requirements
   */
  public preprocess(symptoms: string[]): {
    normalized: string[];
    vector?: number[];
  } {
    if (!Array.isArray(symptoms) || symptoms.length === 0) {
      throw new Error("Symptoms array is required for ML preprocessing.");
    }

    const normalized = symptoms
      .map((s) => s.trim().toLowerCase())
      .filter((s) => s.length > 0);

    // If metadata includes a known feature list (one-hot / multi-hot feature vector)
    if (this.metadata.features && this.metadata.features.length > 0) {
      const vector = this.metadata.features.map((feat) => {
        const featNormalized = feat.trim().toLowerCase();
        return normalized.some((s) => s.includes(featNormalized) || featNormalized.includes(s))
          ? 1
          : 0;
      });
      return { normalized, vector };
    }

    return { normalized };
  }

  /**
   * Perform genuine inference on the trained ML model.
   * If model is not loaded, throws an informative error without fabricating predictions.
   */
  public async predict(symptoms: string[]): Promise<MLPredictionResult> {
    if (!this.isAvailable()) {
      throw new Error(
        "Trained ML model is not available. Real model file is missing or not loaded. Predictions will not be fabricated."
      );
    }

    const preprocessed = this.preprocess(symptoms);

    // 1. If HTTP inference microservice is configured:
    const inferenceUrl = process.env.MODEL_INFERENCE_URL;
    if (inferenceUrl) {
      const response = await fetch(inferenceUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symptoms: preprocessed.normalized,
          vector: preprocessed.vector,
        }),
      });

      if (!response.ok) {
        throw new Error(`ML Inference microservice error: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        isGenuineML: true,
        predictedDisease: data.predictedDisease || data.prediction || "Unknown Condition",
        confidence: typeof data.confidence === "number" ? data.confidence : 0.85,
        confidenceFormatted:
          data.confidenceFormatted ||
          (typeof data.confidence === "number"
            ? `${(data.confidence * 100).toFixed(1)}%`
            : "Confidence N/A"),
        probabilities: data.probabilities,
        rawOutput: data,
        modelType: this.detectedFramework || "ML Microservice",
        timestamp: new Date().toISOString(),
      };
    }

    // 2. Local Python inference bridge if Python model (.pkl/.joblib/.pt)
    if (
      this.modelPath &&
      (this.modelPath.endsWith(".pkl") ||
        this.modelPath.endsWith(".joblib") ||
        this.modelPath.endsWith(".pt") ||
        this.modelPath.endsWith(".h5"))
    ) {
      return await this.runPythonInference(this.modelPath, preprocessed.normalized);
    }

    throw new Error(
      `No inference runner configured for model format '${this.detectedFramework}'. Please supply Python inference script or ONNX model.`
    );
  }

  /**
   * Subprocess bridge to run Python inference when model file is a pickle/joblib/pt
   */
  private runPythonInference(
    modelFile: string,
    symptoms: string[]
  ): Promise<MLPredictionResult> {
    return new Promise((resolve, reject) => {
      const pyScript = path.resolve(process.cwd(), "ml-model", "predict.py");
      const pythonExe = process.env.PYTHON_PATH || "python";

      if (!fs.existsSync(pyScript)) {
        return reject(
          new Error(
            `Inference script '${pyScript}' not found. Please provide predict.py to execute inference on ${modelFile}.`
          )
        );
      }

      const child = spawn(pythonExe, [pyScript, modelFile, JSON.stringify(symptoms)]);
      let stdout = "";
      let stderr = "";

      child.stdout.on("data", (d) => (stdout += d.toString()));
      child.stderr.on("data", (d) => (stderr += d.toString()));

      child.on("close", (code) => {
        if (code !== 0) {
          return reject(
            new Error(`Python ML inference failed with code ${code}: ${stderr || stdout}`)
          );
        }

        try {
          const res = JSON.parse(stdout.trim());
          resolve({
            isGenuineML: true,
            predictedDisease: res.predictedDisease,
            confidence: res.confidence,
            confidenceFormatted: `${(res.confidence * 100).toFixed(1)}%`,
            probabilities: res.probabilities,
            rawOutput: res,
            modelType: this.detectedFramework || "Python Model",
            timestamp: new Date().toISOString(),
          });
        } catch (err: any) {
          reject(new Error(`Failed to parse ML inference JSON output: ${err.message}`));
        }
      });
    });
  }
}

export const mlModelService = new MLModelService();

