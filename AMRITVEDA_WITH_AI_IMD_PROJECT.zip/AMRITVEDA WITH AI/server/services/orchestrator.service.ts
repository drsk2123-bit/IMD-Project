import { groqService, type ChatMessage } from "./groq.service";
import { mlModelService, type MLPredictionResult } from "./ml.service";

export interface OrchestratedDiseaseAssessment {
  predictedDisease: string;
  confidence: string;
  isFromTrainedML: boolean;
  modelInfo: {
    status: string;
    modelType?: string;
  };
  topCandidates?: Array<{ disease: string; confidenceFormatted: string }>;
  matchedFeatures?: string[];
  doshaImbalance: string;
  description: string;
  remedies: string[];
  foods: string[];
  lifestyle: string[];
  yogaPoses: string[];
  avoid: string[];
  disclaimer: string;
}

export interface OrchestratedRemedyResult {
  condition: string;
  remedies: string[];
  naturalTreatments: string[];
  healingFoods: string[];
  herbalTeas: string[];
  oilsAndMassage: string[];
  yogaAndPranayama: string[];
  warnings: string[];
  disclaimer: string;
}

export interface UserChatContext {
  userId?: number;
  name?: string;
  dosha?: string | null;
  bloodGroup?: string | null;
  latestAssessment?: {
    disease: string;
    confidence: string;
    symptoms: string[];
  };
}

export class AIOrchestrator {
  /**
   * Orchestrates Disease Prediction:
   * 1. Invokes the Trained ML model (RandomForestClassifier) for genuine classification & confidence score.
   * 2. Passes the genuine result to Groq AI for clinical Ayurvedic explanation & recommendations.
   * 3. Under no circumstances is Groq allowed to alter or invent model outputs.
   * 4. If Groq is in setup mode or unreachable, seamlessly pairs genuine ML prediction with Ayurvedic clinical rulebase.
   */
  public async assessDisease(
    symptoms: string[],
    fallbackEvaluator: (symptoms: string[]) => any
  ): Promise<OrchestratedDiseaseAssessment> {
    const formattedSymptoms = symptoms.join(", ");
    let mlResult: MLPredictionResult | null = null;

    // Check ML Model Availability
    if (mlModelService.isAvailable()) {
      try {
        mlResult = await mlModelService.predict(symptoms);
      } catch (err: any) {
        console.warn("[Orchestrator] ML Inference error:", err.message);
      }
    }

    const mlHealth = mlModelService.getHealth();
    const hasTrainedML = mlResult !== null;

    // Formulate Groq instructions
    let systemPrompt = "";
    let userPrompt = "";

    if (hasTrainedML) {
      systemPrompt = `You are a master Ayurvedic physician and scholar.
A separate trained machine learning diagnostic model has analyzed the patient's symptoms and output:
- Condition: "${mlResult!.predictedDisease}"
- Confidence: ${mlResult!.confidenceFormatted}

CRITICAL ARCHITECTURAL RULE:
You MUST NOT alter, contradict, or rename the model's predicted condition name. Your job is exclusively to provide the Ayurvedic interpretation, dosha analysis, and holistic treatment recommendations for this EXACT condition.

Respond ONLY in valid JSON matching this schema:
{
  "doshaImbalance": "Vata/Pitta/Kapha/Tridoshic",
  "description": "3-4 sentences explaining this condition from an Ayurvedic perspective and why the symptoms manifest.",
  "remedies": ["Herb/remedy with preparation instructions", ...at least 6 items],
  "foods": ["Recommended healing food item with reason", ...at least 6 items],
  "lifestyle": ["Specific lifestyle adjustment (Dinacharya)", ...at least 4 items],
  "yogaPoses": ["Asana or Pranayama with therapeutic benefit", ...at least 3 items],
  "avoid": ["Specific foods or habits to avoid", ...at least 4 items]
}`;

      userPrompt = `Patient symptoms: ${formattedSymptoms}.\nModel output condition: ${mlResult!.predictedDisease}.`;
    } else {
      systemPrompt = `You are an expert Ayurvedic physician and diagnostician.
Analyze the patient's symptoms and provide an Ayurvedic assessment.

Respond ONLY in valid JSON matching this schema:
{
  "predictedDisease": "Traditional Ayurvedic / clinical condition name",
  "doshaImbalance": "Vata/Pitta/Kapha/Tridoshic",
  "confidence": "e.g. 84%",
  "description": "3-4 sentences explaining this condition from an Ayurvedic perspective.",
  "remedies": ["Herb/remedy with preparation instructions", ...at least 6 items],
  "foods": ["Recommended healing food item with reason", ...at least 6 items],
  "lifestyle": ["Specific lifestyle adjustment (Dinacharya)", ...at least 4 items],
  "yogaPoses": ["Asana or Pranayama with therapeutic benefit", ...at least 3 items],
  "avoid": ["Specific foods or habits to avoid", ...at least 4 items]
}`;

      userPrompt = `Patient symptoms: ${formattedSymptoms}`;
    }

    // Try calling Groq AI
    let groqData: any = null;
    if (groqService.isConfigured()) {
      try {
        groqData = await groqService.chatJSON(systemPrompt, userPrompt, {
          temperature: 0.5,
          maxTokens: 1000,
        });
      } catch (err: any) {
        console.warn("[Orchestrator] Groq API call error:", err.message);
      }
    }

    // If Groq is not configured or failed, use local clinical fallback
    if (!groqData) {
      groqData = fallbackEvaluator(symptoms);
    }

    // Assemble final response
    const predictedDisease = hasTrainedML
      ? mlResult!.predictedDisease
      : groqData.predictedDisease || "General Dosha Imbalance";

    const confidence = hasTrainedML
      ? mlResult!.confidenceFormatted
      : groqData.confidence || "75%";

    return {
      predictedDisease,
      confidence,
      isFromTrainedML: hasTrainedML,
      modelInfo: {
        status: hasTrainedML
          ? `Verified prediction from trained ${mlResult!.modelType}`
          : mlHealth.statusMessage,
        modelType: hasTrainedML ? mlResult!.modelType : undefined,
      },
      topCandidates: hasTrainedML ? mlResult!.rawOutput?.topCandidates : undefined,
      matchedFeatures: hasTrainedML ? mlResult!.rawOutput?.matchedFeatures : undefined,
      doshaImbalance: groqData.doshaImbalance || "Tridoshic",
      description: groqData.description || "Ayurvedic analysis based on reported symptoms.",
      remedies: Array.isArray(groqData.remedies) ? groqData.remedies : [],
      foods: Array.isArray(groqData.foods) ? groqData.foods : [],
      lifestyle: Array.isArray(groqData.lifestyle) ? groqData.lifestyle : [],
      yogaPoses: Array.isArray(groqData.yogaPoses) ? groqData.yogaPoses : [],
      avoid: Array.isArray(groqData.avoid) ? groqData.avoid : [],
      disclaimer:
        "⚕️ AmritVeda Medical Disclaimer: This assessment is generated for educational and wellness guidance only. It does not replace professional medical diagnosis, advice, or treatment. Always consult a licensed Ayurvedic physician or healthcare provider.",
    };
  }

  /**
   * Orchestrates Remedy Generation using Groq AI and Ayurvedic Herbal Knowledge Base
   */
  public async generateRemedies(
    symptoms: string[],
    fallbackEvaluator: (symptoms: string[]) => any
  ): Promise<OrchestratedRemedyResult> {
    const formattedSymptoms = symptoms.join(", ");

    const systemPrompt = `You are a master Ayurvedic herbalist (Dravyaguna expert) with comprehensive knowledge of classical herbs, formulations, spices, and therapies.
Provide detailed, safe, and effective Ayurvedic home remedies for the given symptoms.
Include exact preparation steps and dosage instructions.

Respond ONLY in valid JSON matching this schema:
{
  "condition": "Name of the health condition or doshic imbalance",
  "remedies": ["Specific herb/remedy with preparation and dosage", ...at least 8 items],
  "naturalTreatments": ["External or traditional treatments like Abhyanga, Steam, etc.", ...at least 6 items],
  "healingFoods": ["Food item: therapeutic benefit and consumption method", ...6 items],
  "herbalTeas": ["Herbal tea recipe: ingredients and brewing instructions", ...4 items],
  "oilsAndMassage": ["Therapeutic oil: application method and benefits", ...3 items],
  "yogaAndPranayama": ["Pranayama or posture: practice instructions and benefit", ...4 items],
  "warnings": ["Important safety contraindications or medical precautions", ...at least 4 items]
}`;

    if (groqService.isConfigured()) {
      try {
        const groqData = await groqService.chatJSON(
          systemPrompt,
          `Patient complaints / symptoms: ${formattedSymptoms}`,
          { temperature: 0.5, maxTokens: 2000 }
        );

        return {
          condition: groqData.condition || "Ayurvedic Herbal Therapy",
          remedies: Array.isArray(groqData.remedies) ? groqData.remedies : [],
          naturalTreatments: Array.isArray(groqData.naturalTreatments) ? groqData.naturalTreatments : [],
          healingFoods: Array.isArray(groqData.healingFoods) ? groqData.healingFoods : [],
          herbalTeas: Array.isArray(groqData.herbalTeas) ? groqData.herbalTeas : [],
          oilsAndMassage: Array.isArray(groqData.oilsAndMassage) ? groqData.oilsAndMassage : [],
          yogaAndPranayama: Array.isArray(groqData.yogaAndPranayama) ? groqData.yogaAndPranayama : [],
          warnings: Array.isArray(groqData.warnings) ? groqData.warnings : [],
          disclaimer:
            "⚕️ AmritVeda Herbal Safety Notice: Natural remedies should be used judiciously. If symptoms persist or if you are pregnant, nursing, or on prescribed medication, consult a doctor before starting any herbal regimen.",
        };
      } catch (err: any) {
        console.warn("[Orchestrator] Groq Remedy Generation error:", err.message);
      }
    }

    const fallback = fallbackEvaluator(symptoms);
    return {
      condition: fallback.condition || "Ayurvedic Herbal Therapy",
      remedies: Array.isArray(fallback.remedies) ? fallback.remedies : [],
      naturalTreatments: Array.isArray(fallback.naturalTreatments) ? fallback.naturalTreatments : [],
      healingFoods: Array.isArray(fallback.healingFoods) ? fallback.healingFoods : [],
      herbalTeas: Array.isArray(fallback.herbalTeas) ? fallback.herbalTeas : [],
      oilsAndMassage: Array.isArray(fallback.oilsAndMassage) ? fallback.oilsAndMassage : [],
      yogaAndPranayama: Array.isArray(fallback.yogaAndPranayama) ? fallback.yogaAndPranayama : [],
      warnings: Array.isArray(fallback.warnings) ? fallback.warnings : [],
      disclaimer:
        "⚕️ AmritVeda Herbal Safety Notice: Natural remedies should be used judiciously. If symptoms persist or if you are pregnant, nursing, or on prescribed medication, consult a doctor before starting any herbal regimen.",
    };
  }

  /**
   * Conversational Assistant 'Veda' powered by Groq AI
   * Context-aware: retrieves the patient's verified Dosha Quiz result, name, and health profile.
   */
  public async chatWithVeda(
    userMessage: string,
    conversationHistory: ChatMessage[] = [],
    userContext?: UserChatContext
  ): Promise<string> {
    if (!groqService.isConfigured()) {
      return (
        "Namaste! 🙏 I am Veda, your Ayurvedic wellness assistant. My conversational engine (Groq AI) is currently in setup mode because GROQ_API_KEY has not yet been set in .env. " +
        "Please provide GROQ_API_KEY to unlock interactive real-time consultations. In the meantime, you can explore our Dosha Quiz and Disease Analysis modules powered by our trained ML model!"
      );
    }

    const userName = userContext?.name?.trim() || "Patient";
    const userDosha = userContext?.dosha ? userContext.dosha.trim() : null;
    const hasDosha = Boolean(userDosha && userDosha.length > 0 && userDosha.toLowerCase() !== "null");

    let patientProfileSection = "";
    if (hasDosha) {
      patientProfileSection = `
AUTHENTICATED PATIENT PROFILE & CLINICAL DATA:
- Name: ${userName}
- Stored Dosha Quiz Result: ${userDosha} (VERIFIED COMPLETED QUIZ)
`;
    } else {
      patientProfileSection = `
AUTHENTICATED PATIENT PROFILE & CLINICAL DATA:
- Name: ${userName}
- Stored Dosha Quiz Result: NOT COMPLETED YET (The patient has not completed the Dosha Quiz)
`;
    }

    if (userContext?.latestAssessment) {
      patientProfileSection += `- Recent ML Disease Assessment: ${userContext.latestAssessment.disease} (${userContext.latestAssessment.confidence} confidence) for symptoms: ${userContext.latestAssessment.symptoms.join(", ")}\n`;
    }

    const systemPrompt = `You are Veda, the wise, warm, and attentive Ayurvedic wellness assistant at AmritVeda, powered by Groq AI.
${patientProfileSection}

CRITICAL RULES FOR PERSONALIZED DOSHA RESPONSES:
1. KNOWING THE PATIENT'S DOSHA:
   - When the user asks "What is my Dosha?" (or asks what their body constitution / Prakriti is):
     * If the Stored Dosha Quiz Result is available (e.g. "${userDosha}"):
       You MUST answer directly with their exact quiz result. Never give a generic breakdown of all three doshas or ask the user to figure out their dosha.
       Follow this exact structure and tone:
       "Namaste! Based on your Dosha Quiz results, your dominant Dosha is ${userDosha}.

${userDosha} is associated with the [elements for this dosha] and represents [qualities/attributes] in Ayurveda.

To maintain balance, focus on [2-3 concise lifestyle and dietary recommendations for this dosha].

Your quiz indicates ${userDosha} as your dominant Dosha."

     * If the Stored Dosha Quiz Result is NOT COMPLETED YET:
       Tell the user directly, warmly and clearly:
       "Namaste! You haven't completed the Dosha Quiz yet. Please complete the Dosha Quiz under the Tools section so I can determine your dominant constitution and provide your personalized results."

2. BALANCING THE DOSHA:
   - When the user asks "How can I balance my Dosha?" or asks for remedies for their dosha:
     * If their Dosha is known (e.g. "${userDosha}"):
       Directly provide concise, actionable recommendations tailored specifically to balancing ${userDosha} (warm vs cooling foods, routine, appropriate herbs like Ashwagandha/Brahmi/Triphala, gentle exercise, sleep).
     * If their Dosha is not known:
       Politely recommend completing the Dosha Quiz first to discover their specific constitution, while offering general holistic Ayurvedic advice.

3. RESPONSE STYLE:
   - Keep answers short, clear, personalized, and conversational (2-3 concise paragraphs, avoiding unnecessary length).
   - Answer the exact question asked directly.
   - Use simple language that anyone can easily understand.
   - Never invent or fabricate personal medical data.
   - Avoid generic multi-page essays when personalized data is present.`;

    const messages: ChatMessage[] = [
      { role: "system", content: systemPrompt },
      ...conversationHistory.slice(-8),
      { role: "user", content: userMessage },
    ];

    try {
      return await groqService.chatCompletion(messages, {
        temperature: 0.6,
        maxTokens: 400,
      });
    } catch (err: any) {
      console.error("[Orchestrator] Chat error with Groq:", err.message);
      return (
        "Namaste! 🙏 I encountered a temporary connection issue while reaching Groq AI. " +
        `Error details: ${err.message}. Please verify your network and GROQ_API_KEY configuration.`
      );
    }
  }
}

export const aiOrchestrator = new AIOrchestrator();
