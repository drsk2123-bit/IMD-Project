import { db } from "./db";
import {
  users, predictions, treatments,
  type User, type InsertUser, type UpdateUser,
  type Prediction, type InsertPrediction,
  type Treatment, type InsertTreatment
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: UpdateUser): Promise<User>;

  getPredictions(userId: number): Promise<Prediction[]>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;

  getPractitionerPatients(practitionerId: number): Promise<User[]>;
  getPatientReview(patientId: number): Promise<{
    patient: User | undefined;
    predictions: Prediction[];
    treatments: Treatment[];
  }>;
  getPatientVisibleTreatments(patientId: number): Promise<Array<Treatment & { practitionerName: string }>>;
  getPatientTreatments(patientId: number): Promise<Treatment[]>;
  createTreatment(treatment: InsertTreatment): Promise<Treatment>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: UpdateUser): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getPredictions(userId: number): Promise<Prediction[]> {
    return await db.select().from(predictions).where(eq(predictions.userId, userId));
  }

  async createPrediction(prediction: InsertPrediction): Promise<Prediction> {
    const [pred] = await db.insert(predictions).values(prediction).returning();
    return pred;
  }

  async getPractitionerPatients(practitionerId: number): Promise<User[]> {
    // In a real app we'd have a mapping table, but for now we'll just return all patients
    return await db.select().from(users).where(eq(users.role, "patient"));
  }

  async getPatientReview(patientId: number): Promise<{
    patient: User | undefined;
    predictions: Prediction[];
    treatments: Treatment[];
  }> {
    const [patient, patientPredictions, patientTreatments] = await Promise.all([
      this.getUser(patientId),
      this.getPredictions(patientId),
      this.getPatientTreatments(patientId),
    ]);

    return {
      patient,
      predictions: patientPredictions,
      treatments: patientTreatments,
    };
  }

  async getPatientVisibleTreatments(patientId: number): Promise<Array<Treatment & { practitionerName: string }>> {
    const practitioner = users;

    const rows = await db
      .select({
        id: treatments.id,
        practitionerId: treatments.practitionerId,
        patientId: treatments.patientId,
        notes: treatments.notes,
        createdAt: treatments.createdAt,
        practitionerName: practitioner.name,
      })
      .from(treatments)
      .leftJoin(practitioner, eq(treatments.practitionerId, practitioner.id))
      .where(eq(treatments.patientId, patientId));

    return rows.map((row) => ({
      id: row.id,
      practitionerId: row.practitionerId,
      patientId: row.patientId,
      notes: row.notes,
      createdAt: row.createdAt,
      practitionerName: row.practitionerName || "Practitioner",
    }));
  }

  async getPatientTreatments(patientId: number): Promise<Treatment[]> {
    return await db.select().from(treatments).where(eq(treatments.patientId, patientId));
  }

  async createTreatment(treatment: InsertTreatment): Promise<Treatment> {
    const [trt] = await db.insert(treatments).values(treatment).returning();
    return trt;
  }
}

export const storage = new DatabaseStorage();
